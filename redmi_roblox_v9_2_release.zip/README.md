# Redmi Roblox v9.2 Adaptive

Target: Redmi 15 4G / HyperOS 3 / Android 16 / Snapdragon 685 / Shizuku UID 2000.

## Install on phone

Copy `scripts/redmi_roblox_v9_2_adaptive.sh` to:

```text
/storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh
```

Then run in aShell You or AXManager:

```sh
chmod +x /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh
sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh --fresh
```

Use `--fresh` the first time or when stale state/pid files may exist.

Normal daily use:

```sh
sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh engage
```

Stop and restore:

```sh
sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh stop
```

Verify:

```sh
sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh verify
```

## Modes

```text
engage      adaptive engage based on Battery Saver state
--fresh     stop stale daemon, clear v9.2 state, then engage
stop        stop daemon and restore saved baseline
verify      readback
full        force full profile
saver       force saver profile
events480   A/B test max_events 480
events1600  A/B test max_events 1600
events9999  A/B test max_events 9999
scale025    A/B test downscale 0.25 + 120 FPS
scale035    A/B test downscale 0.35 + 120 FPS
grip90      A/B test debug.tp.grip_enable 90
grip120     A/B test debug.tp.grip_enable 120
grip150     A/B test debug.tp.grip_enable 150
```

## Expected full readback

```text
Scaling:0.25
Fps:120
GameFrameRateOverrides={10490, 120 0}
renderRate=120.00 Hz
max_events=9999
grip_debug=90
RUN_IN_BACKGROUND: allow
RUN_ANY_IN_BACKGROUND: allow
WAKE_LOCK: allow
```

## Safety exclusions

No root-only `/sys` or `/proc` writes, no device_config, no thermal spoofing, no raw service calls, no background_process_limit=2, no am kill-all, no ANGLE/developer graphics forcing, no GMS/Play Store/Discord/pedometer/ChatGPT changes.
