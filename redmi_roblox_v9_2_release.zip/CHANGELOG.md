# Changelog

## v9.2

- Added v9.2 adaptive script.
- Added `--fresh` stale-state reset mode.
- Added A/B modes: events480, events1600, events9999, scale025, scale035, grip90, grip120, grip150.
- Default full profile: 0.25 downscale, 120 FPS, 120 Hz, max_events 9999, resampling false, touch prediction false, velocitytracker impulse, debug.tp.grip_enable 90.
- Keeps Roblox priority with AppOps allow, DeviceIdle whitelist, standby active, and PID-guarded `am compact`.
- Uses safe PID-file daemon logic.
- Avoids banned/root-only commands and protected Google/Discord/pedometer/ChatGPT packages.
