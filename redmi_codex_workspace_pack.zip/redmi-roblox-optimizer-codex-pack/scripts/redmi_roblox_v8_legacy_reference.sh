#!/system/bin/sh
# Redmi Roblox v8 — Shizuku UID 2000 / HyperOS 3 / Android 16
# Target: com.roblox.client
# Default game intervention: downscale 0.25 + fps 120
# No device_config, no thermal spoofing, no background_process_limit, no Discord/pedometer restrictions.

BASE="/storage/emulated/0/Download"
GAME="com.roblox.client"
STATE="$BASE/redmi_roblox_v8.state"
LOCK="$BASE/redmi_roblox_v8.lock"
LOG="$BASE/redmi_roblox_v8.log"
DOWN="0.25"
FPS="120"
RB_NULL="__RB_NULL__"
RB_EMPTY="__RB_EMPTY__"

HOGS_USER0="com.zhiliaoapp.musically com.brave.browser com.google.android.googlequicksearchbox com.xiaomi.aicr com.miui.mediaeditor com.miui.analytics"

PROPS_DEFAULT="debug.sf.set_idle_timer_ms debug.sf.latch_unsignaled debug.sf.enable_gl_backpressure debug.sf.disable_backpressure debug.hwui.renderer debug.hwui.render_backend debug.renderengine.backend debug.input.resampling debug.input.touch_prediction debug.input.interceptdispatchtimeout_ms debug.input.multitouch_min_distance debug.input.quiet_interval debug.velocitytracker.strategy"
SETTINGS_DEFAULT="system:pointer_location system:show_touches global:enable_gpu_debug_layers global:gpu_debug_app global:gpu_debug_layers global:gpu_debug_layers_app"

log() {
    mkdir -p "$BASE" 2>/dev/null
    echo "$(date +%F_%T) $*" | tee -a "$LOG"
}

try() {
    "$@" >> "$LOG" 2>&1 || true
}

rotate_log() {
    [ -f "$LOG" ] || return 0
    SZ="$(wc -c < "$LOG" 2>/dev/null)"
    [ -n "$SZ" ] || return 0
    if [ "$SZ" -gt 1048576 ]; then
        mv "$LOG" "$LOG.old" 2>/dev/null || true
    fi
}

state_put() {
    KEY="$1"
    VAL="$2"
    mkdir -p "$BASE" 2>/dev/null
    if [ -f "$STATE" ]; then
        awk -F= -v k="$KEY" 'index($0,k"=")!=1{print}' "$STATE" > "$STATE.tmp" 2>/dev/null && mv "$STATE.tmp" "$STATE"
    fi
    printf "%s=%s\n" "$KEY" "$VAL" >> "$STATE"
}

state_get() {
    KEY="$1"
    [ -f "$STATE" ] || return 0
    awk -F= -v k="$KEY" 'index($0,k"=")==1{sub("^[^=]*=",""); print; exit}' "$STATE" 2>/dev/null
}

state_has() {
    KEY="$1"
    [ -f "$STATE" ] || return 1
    awk -F= -v k="$KEY" 'index($0,k"=")==1{found=1} END{exit !found}' "$STATE" 2>/dev/null
}

save_prop_once() {
    KEY="$1"
    state_has "prop:$KEY" && return 0
    VAL="$(getprop "$KEY" 2>/dev/null)"
    [ -z "$VAL" ] && VAL="$RB_EMPTY"
    state_put "prop:$KEY" "$VAL"
}

restore_prop() {
    KEY="$1"
    VAL="$(state_get "prop:$KEY")"
    [ -z "$VAL" ] && return 0
    [ "$VAL" = "$RB_EMPTY" ] && VAL=""
    try setprop "$KEY" "$VAL"
}

save_setting_once() {
    NS="$1"
    KEY="$2"
    state_has "setting:$NS:$KEY" && return 0
    VAL="$(settings get "$NS" "$KEY" 2>/dev/null)"
    case "$VAL" in ""|null) VAL="$RB_NULL" ;; esac
    state_put "setting:$NS:$KEY" "$VAL"
}

restore_setting() {
    NS="$1"
    KEY="$2"
    VAL="$(state_get "setting:$NS:$KEY")"
    [ -z "$VAL" ] && return 0
    if [ "$VAL" = "$RB_NULL" ]; then
        try settings delete "$NS" "$KEY"
    else
        try settings put "$NS" "$KEY" "$VAL"
    fi
}

pkg_exists_user() {
    U="$1"
    P="$2"
    cmd package list packages --user "$U" "$P" 2>/dev/null | grep -Fxq "package:$P"
}

appop_mode() {
    U="$1"
    P="$2"
    OP="$3"
    OUT="$(appops get --user "$U" "$P" "$OP" 2>/dev/null)"
    echo "$OUT" | awk -v op="$OP" '$1==op":" {gsub(";","",$2); print $2; found=1} END{if(!found) print "default"}'
}

save_appop_once() {
    U="$1"
    P="$2"
    OP="$3"
    state_has "appop:$U:$P:$OP" && return 0
    MODE="$(appop_mode "$U" "$P" "$OP")"
    [ -z "$MODE" ] && MODE="default"
    state_put "appop:$U:$P:$OP" "$MODE"
}

restore_appop() {
    U="$1"
    P="$2"
    OP="$3"
    MODE="$(state_get "appop:$U:$P:$OP")"
    [ -z "$MODE" ] && return 0
    pkg_exists_user "$U" "$P" || return 0
    try appops set --user "$U" "$P" "$OP" "$MODE"
}

is_whitelisted() {
    P="$1"
    cmd deviceidle whitelist 2>/dev/null | sed 's/^[[:space:]]*//' | grep -Fxq "$P"
}

save_game_state_once() {
    state_has "game:mode" && return 0
    MODE="$(cmd game list-modes "$GAME" 2>/dev/null | sed -n 's/.*current mode: \([^,]*\).*/\1/p' | head -1)"
    [ -z "$MODE" ] && MODE="unknown"
    LINE="$(dumpsys game 2>/dev/null | grep -i "Name:$GAME" | head -1)"
    SCALE="$(echo "$LINE" | sed -n 's/.*Scaling:\([^,}]*\).*/\1/p')"
    GFPS="$(echo "$LINE" | sed -n 's/.*Fps:\([^,}]*\).*/\1/p')"
    [ -z "$SCALE" ] && SCALE="$RB_EMPTY"
    [ -z "$GFPS" ] && GFPS="0"
    state_put "game:mode" "$MODE"
    state_put "game:scale" "$SCALE"
    state_put "game:fps" "$GFPS"
}

apply_game_025() {
    log "Applying GameManager: downscale=$DOWN fps=$FPS"
    try cmd game set --downscale "$DOWN" --fps "$FPS" "$GAME"
    try cmd game mode custom "$GAME"
}

restore_game() {
    MODE="$(state_get "game:mode")"
    SCALE="$(state_get "game:scale")"
    GFPS="$(state_get "game:fps")"
    [ -z "$MODE" ] && MODE="standard"
    case "$MODE" in
        custom)
            if [ -n "$SCALE" ] && [ "$SCALE" != "$RB_EMPTY" ]; then
                [ -z "$GFPS" ] && GFPS="0"
                try cmd game set --downscale "$SCALE" --fps "$GFPS" "$GAME"
            fi
            try cmd game mode custom "$GAME"
            ;;
        standard)
            try cmd game mode standard "$GAME"
            ;;
        *)
            try cmd game mode standard "$GAME"
            ;;
    esac
}

verify_game_min() {
    dumpsys game 2>/dev/null | grep -i "Name:$GAME" | grep -q "Scaling:$DOWN" || return 1
    dumpsys game 2>/dev/null | grep -i "Name:$GAME" | grep -q "Fps:$FPS" || return 1
    return 0
}

save_default_state_once() {
    save_game_state_once

    for K in $PROPS_DEFAULT; do
        save_prop_once "$K"
    done

    for ITEM in $SETTINGS_DEFAULT; do
        NS="${ITEM%%:*}"
        KEY="${ITEM#*:}"
        save_setting_once "$NS" "$KEY"
    done

    for OP in RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND WAKE_LOCK; do
        save_appop_once 0 "$GAME" "$OP"
    done

    BUCKET="$(am get-standby-bucket "$GAME" 2>/dev/null | head -1)"
    [ -z "$BUCKET" ] && BUCKET="$RB_EMPTY"
    state_put "standby:$GAME" "$BUCKET"

    if is_whitelisted "$GAME"; then
        state_put "deviceidle_added:$GAME" "0"
    else
        state_put "deviceidle_added:$GAME" "1"
    fi

    for P in $HOGS_USER0; do
        pkg_exists_user 0 "$P" || continue
        for OP in RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND WAKE_LOCK; do
            save_appop_once 0 "$P" "$OP"
        done
    done
}

apply_props_default() {
    log "Applying props"
    try setprop debug.sf.set_idle_timer_ms 0
    try setprop debug.sf.latch_unsignaled 1
    try setprop debug.sf.enable_gl_backpressure 0
    try setprop debug.sf.disable_backpressure 1
    try setprop debug.hwui.renderer skiavk
    try setprop debug.hwui.render_backend skiavk
    try setprop debug.renderengine.backend skiavkthreaded
    try setprop debug.input.resampling false
    try setprop debug.input.touch_prediction false
    try setprop debug.input.interceptdispatchtimeout_ms 0
    try setprop debug.input.multitouch_min_distance 0
    try setprop debug.input.quiet_interval 0
    try setprop debug.velocitytracker.strategy impulse
}

apply_settings_cleanup() {
    log "Applying safe settings cleanup"
    try settings put system pointer_location 0
    try settings put system show_touches 0
    try settings put global enable_gpu_debug_layers 0
    try settings delete global gpu_debug_app
    try settings delete global gpu_debug_layers
    try settings delete global gpu_debug_layers_app
}

apply_roblox_priority() {
    log "Applying Roblox priority"
    for OP in RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND WAKE_LOCK; do
        try appops set --user 0 "$GAME" "$OP" allow
    done
    try am set-inactive "$GAME" false
    try am set-standby-bucket "$GAME" active

    if ! is_whitelisted "$GAME"; then
        try cmd deviceidle whitelist +"$GAME"
    fi
}

apply_hog_restrictions() {
    log "Restricting non-call hogs. Discord, pedometer, ChatGPT, GMS, Play Store are not touched."
    for P in $HOGS_USER0; do
        pkg_exists_user 0 "$P" || continue
        try appops set --user 0 "$P" RUN_IN_BACKGROUND deny
        try appops set --user 0 "$P" RUN_ANY_IN_BACKGROUND deny
        try appops set --user 0 "$P" WAKE_LOCK deny
        case "$P" in
            com.miui.analytics) ;;
            *) try am force-stop "$P" ;;
        esac
    done
}

compact_roblox() {
    PID="$(pidof "$GAME" 2>/dev/null | awk '{print $1}')"
    [ -n "$PID" ] || return 0
    log "Compacting Roblox pid=$PID"
    try am compact "$PID"
}

guard_engage() {
    mkdir -p "$BASE" 2>/dev/null
    if [ -f "$LOCK" ]; then
        log "Already engaged or stale lock exists: $LOCK. Run stop first."
        exit 1
    fi
    echo "$$ $(date +%s)" > "$LOCK"
}

engage_common() {
    MODE="$1"
    rotate_log
    guard_engage
    : > "$STATE"
    log "=== ENGAGE v8 mode=$MODE downscale=$DOWN fps=$FPS ==="

    save_default_state_once
    apply_props_default
    apply_settings_cleanup
    apply_roblox_priority

    if [ "$MODE" != "callmode" ]; then
        apply_hog_restrictions
    else
        log "callmode: skipping hog restrictions for maximum call safety"
    fi

    apply_game_025
    compact_roblox

    if verify_game_min; then
        state_put "engaged" "1"
        log "ENGAGE OK"
        verify
        exit 0
    fi

    log "ENGAGE FAILED: GameManager readback did not show Scaling:$DOWN and Fps:$FPS. Rolling back."
    restore_all_keep_files
    rm -f "$LOCK"
    exit 1
}

restore_all_keep_files() {
    log "Restoring GameManager"
    restore_game

    log "Restoring props"
    for K in $PROPS_DEFAULT debug.sf.predict_hwc_composition_strategy debug.sf.enable_adpf_cpu_hint debug.sf.frame_rate_multiple_threshold debug.hwui.use_hint_manager debug.hwui.target_cpu_time_percent; do
        restore_prop "$K"
    done

    log "Restoring settings"
    for ITEM in $SETTINGS_DEFAULT; do
        NS="${ITEM%%:*}"
        KEY="${ITEM#*:}"
        restore_setting "$NS" "$KEY"
    done

    log "Restoring Roblox appops / standby / deviceidle"
    for OP in RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND WAKE_LOCK; do
        restore_appop 0 "$GAME" "$OP"
    done

    BUCKET="$(state_get "standby:$GAME")"
    if [ -n "$BUCKET" ] && [ "$BUCKET" != "$RB_EMPTY" ]; then
        try am set-standby-bucket "$GAME" "$BUCKET"
    fi

    ADDED="$(state_get "deviceidle_added:$GAME")"
    if [ "$ADDED" = "1" ]; then
        try cmd deviceidle whitelist -"$GAME"
    fi

    log "Restoring hog appops"
    for P in $HOGS_USER0; do
        for OP in RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND WAKE_LOCK; do
            restore_appop 0 "$P" "$OP"
        done
    done
}

stop_mode() {
    rotate_log
    if [ ! -f "$STATE" ] && [ ! -f "$LOCK" ]; then
        echo "No active v8 state found."
        exit 0
    fi
    log "=== STOP v8 ==="
    restore_all_keep_files
    rm -f "$LOCK" "$STATE"
    log "STOP OK"
    verify
}

sfplus_mode() {
    rotate_log
    [ -f "$STATE" ] || : > "$STATE"
    log "=== SFPLUS A/B TEST ==="
    for K in debug.sf.predict_hwc_composition_strategy debug.sf.enable_adpf_cpu_hint debug.sf.frame_rate_multiple_threshold debug.hwui.use_hint_manager debug.hwui.target_cpu_time_percent; do
        save_prop_once "$K"
    done
    try setprop debug.sf.predict_hwc_composition_strategy 1
    try setprop debug.sf.enable_adpf_cpu_hint 1
    try setprop debug.sf.frame_rate_multiple_threshold 0
    try setprop debug.hwui.use_hint_manager 1
    log "SFPLUS applied. Use stop to restore if state exists."
    verify
}

display120_mode() {
    log "=== DISPLAY120 optional dirty mode ==="
    cmd display set-user-preferred-display-mode 1080 2340 120 2>&1 | tee -a "$LOG"
    cmd display get-user-preferred-display-mode 2>&1 | tee -a "$LOG"
}

displayclear_mode() {
    log "=== DISPLAYCLEAR ==="
    cmd display clear-user-preferred-display-mode 2>&1 | tee -a "$LOG"
    cmd display get-user-preferred-display-mode 2>&1 | tee -a "$LOG"
}

compile_profile_mode() {
    log "=== COMPILE PROFILE ==="
    cmd package compile -m speed-profile -f "$GAME" 2>&1 | tee -a "$LOG"
}

compile_speed_mode() {
    log "=== COMPILE SPEED ==="
    cmd package compile -m speed -f "$GAME" 2>&1 | tee -a "$LOG"
}

verify() {
    echo "=== v8 VERIFY ==="
    echo "script=$0"
    echo "state=$STATE"
    echo "lock=$LOCK"
    echo ""
    echo "## GAME"
    cmd game list-modes "$GAME" 2>&1
    dumpsys game 2>/dev/null | grep -A6 -i "$GAME"
    echo ""
    echo "## PROPS"
    for K in debug.sf.set_idle_timer_ms debug.sf.latch_unsignaled debug.sf.enable_gl_backpressure debug.sf.disable_backpressure debug.input.resampling debug.input.touch_prediction debug.velocitytracker.strategy debug.hwui.renderer debug.renderengine.backend debug.sf.predict_hwc_composition_strategy debug.sf.enable_adpf_cpu_hint debug.sf.frame_rate_multiple_threshold; do
        echo "$K=$(getprop "$K" 2>/dev/null)"
    done
    echo ""
    echo "## ROBLOX PRIORITY"
    am get-standby-bucket "$GAME" 2>&1
    appops get "$GAME" RUN_IN_BACKGROUND 2>&1
    appops get "$GAME" RUN_ANY_IN_BACKGROUND 2>&1
    appops get "$GAME" WAKE_LOCK 2>&1
    cmd deviceidle whitelist 2>/dev/null | grep -F "$GAME" || true
    echo ""
    echo "## SAFETY"
    echo "background_process_limit=$(settings get global background_process_limit 2>/dev/null)"
    echo "pedometer_not_touched=pedometer.steptracker.calorieburner.stepcounter"
    echo "discord_not_touched=com.discord user0/user999"
}

verify_full() {
    verify
    echo ""
    echo "## SURFACEFLINGER GAME OVERRIDE"
    dumpsys SurfaceFlinger 2>/dev/null | grep -A4 -B4 -E "GameFrameRateOverrides|10490|renderRate=|activeMode=" | head -120
    echo ""
    echo "## ROBLOX GFXINFO SUMMARY"
    dumpsys gfxinfo "$GAME" 2>/dev/null | grep -E "Total frames rendered|Janky frames|90th percentile|95th percentile|99th percentile|Number Missed Vsync|Number High input latency|Number Slow UI thread|HISTOGRAM" | head -120
    echo ""
    echo "## ROBLOX MEMINFO"
    dumpsys meminfo "$GAME" 2>/dev/null | grep -E "TOTAL|Native Heap|Dalvik Heap|Graphics|GL mtrack|App Summary|TOTAL PSS|oom|pid" | head -80
    echo ""
    echo "## THERMAL"
    dumpsys thermalservice 2>/dev/null | grep -E "IsStatusOverride|Thermal Status|skin|GPU|CPU|headroom|Status" | head -80
}

case "${1:-engage}" in
    engage|start|on)
        engage_common "engage"
        ;;
    callmode|call)
        engage_common "callmode"
        ;;
    stop|off|restore)
        stop_mode
        ;;
    verify|status)
        verify
        ;;
    verify_full|full)
        verify_full
        ;;
    sfplus)
        sfplus_mode
        ;;
    display120)
        display120_mode
        ;;
    displayclear)
        displayclear_mode
        ;;
    compile_profile)
        compile_profile_mode
        ;;
    compile_speed)
        compile_speed_mode
        ;;
    *)
        echo "Usage: sh $0 engage|callmode|stop|verify|verify_full|sfplus|display120|displayclear|compile_profile|compile_speed"
        exit 1
        ;;
esac

exit 0
