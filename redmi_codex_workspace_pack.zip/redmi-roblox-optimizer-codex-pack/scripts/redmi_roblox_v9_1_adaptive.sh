#!/system/bin/sh
# Redmi Roblox v9.1 Adaptive — HyperOS 3 / Android 16 / Shizuku UID 2000
# Battery Saver OFF -> Roblox 0.25 + 120 FPS + MaxTouch 9999
# Battery Saver ON  -> Roblox 0.25 + 60 FPS + MaxEvents 480
# Safe daemon handling: uses PID files, avoids dangerous broad pkill patterns.
# Does NOT touch Discord, cloned Discord, pedometer, ChatGPT, GMS, or Play Store.

BASE="/storage/emulated/0/Download"
GAME="com.roblox.client"
SELF_BASENAME="redmi_roblox_v9_1_adaptive.sh"

LOG="$BASE/redmi_roblox_v9_1_adaptive.log"
STATE="$BASE/redmi_roblox_v9_1_adaptive.state"
PIDFILE="$BASE/redmi_roblox_v9_1_adaptive.pid"

# Old daemon pidfiles to stop.
OLD_PIDFILES="$BASE/redmi_roblox_v9_adaptive.pid $BASE/rb_battery_adaptive.pid"

DOWN="0.25"
FULL_FPS="120"
SAVER_FPS="60"
FULL_EVENTS="9999"
SAVER_EVENTS="480"

RB_NULL="__RB_NULL__"
RB_EMPTY="__RB_EMPTY__"

# Safe cleanup list only. No Discord, pedometer, ChatGPT, GMS, or Play Store.
HOGS_USER0="com.zhiliaoapp.musically com.brave.browser com.google.android.googlequicksearchbox com.xiaomi.aicr com.miui.mediaeditor com.miui.analytics"

PROPS_SAVE="debug.inputdispatcher.max_events_per_sec debug.input.resampling debug.input.touch_prediction debug.velocitytracker.strategy debug.input.interceptdispatchtimeout_ms debug.input.multitouch_min_distance debug.input.quiet_interval"
SETTINGS_SAVE="global:high_touch_mode secure:miui_touch_boost secure:game_touch_mode secure:game_turbo_touch_sensitivity global:input.instant_touch_response global:input.touch_boost system:input.touch_boost global:touch.sampling_boost global:touch.polling_rate global:touch_sampling_rate_override global:touch_response_rate global:touch_rate_control global:windowsmgr.support_low_latency_touch system:touch_sampling_rate system:touch_sampling_rate_override system:devices_virtual_input_input1_polling_rate system:input.high_update_rate system:touch_response_rate system:touch_rate_control system:min_refresh_rate system:peak_refresh_rate system:user_refresh_rate system:miui_refresh_rate"

log() {
    mkdir -p "$BASE" 2>/dev/null
    echo "$(date +%F_%T) $*" | tee -a "$LOG"
}

try() { "$@" >> "$LOG" 2>&1 || true; }

rotate_log() {
    [ -f "$LOG" ] || return 0
    SZ="$(wc -c < "$LOG" 2>/dev/null)"
    [ -n "$SZ" ] || return 0
    [ "$SZ" -gt 1048576 ] && mv "$LOG" "$LOG.old" 2>/dev/null || true
}

state_put() {
    KEY="$1"; VAL="$2"
    mkdir -p "$BASE" 2>/dev/null
    if [ -f "$STATE" ]; then
        awk -F= -v k="$KEY" 'index($0,k"=")!=1{print}' "$STATE" > "$STATE.tmp" 2>/dev/null && mv "$STATE.tmp" "$STATE"
    fi
    printf "%s=%s\n" "$KEY" "$VAL" >> "$STATE"
}

state_get() {
    KEY="$1"
    [ -f "$STATE" ] || return 0
    awk -F= -v k="$KEY" 'index($0,k"=")==1{sub("^[^=]*=",""); print; exit}' "$STATE" 2>/dev/null
}

state_has() {
    KEY="$1"
    [ -f "$STATE" ] || return 1
    awk -F= -v k="$KEY" 'index($0,k"=")==1{found=1} END{exit !found}' "$STATE" 2>/dev/null
}

save_prop_once() {
    KEY="$1"
    state_has "prop:$KEY" && return 0
    VAL="$(getprop "$KEY" 2>/dev/null)"
    [ -z "$VAL" ] && VAL="$RB_EMPTY"
    state_put "prop:$KEY" "$VAL"
}

restore_prop() {
    KEY="$1"
    VAL="$(state_get "prop:$KEY")"
    [ -z "$VAL" ] && return 0
    [ "$VAL" = "$RB_EMPTY" ] && VAL=""
    try setprop "$KEY" "$VAL"
}

save_setting_once() {
    NS="$1"; KEY="$2"
    state_has "setting:$NS:$KEY" && return 0
    VAL="$(settings get "$NS" "$KEY" 2>/dev/null)"
    case "$VAL" in ""|null) VAL="$RB_NULL" ;; esac
    state_put "setting:$NS:$KEY" "$VAL"
}

restore_setting() {
    NS="$1"; KEY="$2"
    VAL="$(state_get "setting:$NS:$KEY")"
    [ -z "$VAL" ] && return 0
    if [ "$VAL" = "$RB_NULL" ]; then
        try settings delete "$NS" "$KEY"
    else
        try settings put "$NS" "$KEY" "$VAL"
    fi
}

pkg_exists_user() {
    U="$1"; P="$2"
    cmd package list packages --user "$U" "$P" 2>/dev/null | grep -Fxq "package:$P"
}

appop_mode() {
    U="$1"; P="$2"; OP="$3"
    OUT="$(appops get --user "$U" "$P" "$OP" 2>/dev/null)"
    echo "$OUT" | awk -v op="$OP" '$1==op":" {gsub(";","",$2); print $2; found=1} END{if(!found) print "default"}'
}

save_appop_once() {
    U="$1"; P="$2"; OP="$3"
    state_has "appop:$U:$P:$OP" && return 0
    MODE="$(appop_mode "$U" "$P" "$OP")"
    [ -z "$MODE" ] && MODE="default"
    state_put "appop:$U:$P:$OP" "$MODE"
}

restore_appop() {
    U="$1"; P="$2"; OP="$3"
    MODE="$(state_get "appop:$U:$P:$OP")"
    [ -z "$MODE" ] && return 0
    pkg_exists_user "$U" "$P" || return 0
    try appops set --user "$U" "$P" "$OP" "$MODE"
}

is_whitelisted() {
    P="$1"
    cmd deviceidle whitelist 2>/dev/null | sed 's/^[[:space:]]*//' | grep -Fxq "$P"
}

save_game_state_once() {
    state_has "game:mode" && return 0
    MODE="$(cmd game list-modes "$GAME" 2>/dev/null | sed -n 's/.*current mode: \([^,]*\).*/\1/p' | head -1)"
    [ -z "$MODE" ] && MODE="unknown"
    LINE="$(dumpsys game 2>/dev/null | grep -i "Name:$GAME" | head -1)"
    SCALE="$(echo "$LINE" | sed -n 's/.*Scaling:\([^,}]*\).*/\1/p')"
    GFPS="$(echo "$LINE" | sed -n 's/.*Fps:\([^,}]*\).*/\1/p')"
    [ -z "$SCALE" ] && SCALE="$RB_EMPTY"
    [ -z "$GFPS" ] && GFPS="0"
    state_put "game:mode" "$MODE"
    state_put "game:scale" "$SCALE"
    state_put "game:fps" "$GFPS"
}

restore_game() {
    MODE="$(state_get "game:mode")"
    SCALE="$(state_get "game:scale")"
    GFPS="$(state_get "game:fps")"
    [ -z "$MODE" ] && MODE="standard"
    case "$MODE" in
        custom)
            if [ -n "$SCALE" ] && [ "$SCALE" != "$RB_EMPTY" ]; then
                [ -z "$GFPS" ] && GFPS="0"
                try cmd game set --downscale "$SCALE" --fps "$GFPS" "$GAME"
            fi
            try cmd game mode custom "$GAME"
            ;;
        standard) try cmd game mode standard "$GAME" ;;
        *) try cmd game mode standard "$GAME" ;;
    esac
}

stop_pidfile() {
    PF="$1"
    [ -f "$PF" ] || return 0
    PID="$(cat "$PF" 2>/dev/null)"
    if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
        # Do not kill our current shell/process.
        if [ "$PID" != "$$" ]; then
            kill "$PID" 2>/dev/null || true
            sleep 0.2
            kill -9 "$PID" 2>/dev/null || true
        fi
    fi
    rm -f "$PF"
}

stop_legacy_daemons() {
    log "Stopping old daemon PID files safely"
    for PF in $OLD_PIDFILES; do
        stop_pidfile "$PF"
    done

    # Safer legacy cleanup: only kill exact old script processes from ps list, never current pid.
    ME="$$"
    ps -ef 2>/dev/null | awk '/rb_battery_adaptive\.sh|roblox_telemetry_v2\.sh daemon|roblox_telemetry\.sh daemon|redmi_roblox_v9_adaptive\.sh/ && !/awk/ {print $2}' | while read P; do
        [ -n "$P" ] || continue
        [ "$P" = "$ME" ] && continue
        kill "$P" 2>/dev/null || true
    done

    rm -f "$BASE/redmi_roblox_v8.lock"
}

save_all_once() {
    rotate_log
    [ -f "$STATE" ] || : > "$STATE"
    save_game_state_once

    for K in $PROPS_SAVE; do save_prop_once "$K"; done

    for ITEM in $SETTINGS_SAVE; do
        NS="${ITEM%%:*}"; KEY="${ITEM#*:}"
        save_setting_once "$NS" "$KEY"
    done

    for OP in RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND WAKE_LOCK; do
        save_appop_once 0 "$GAME" "$OP"
    done

    BUCKET="$(am get-standby-bucket "$GAME" 2>/dev/null | head -1)"
    [ -z "$BUCKET" ] && BUCKET="$RB_EMPTY"
    state_put "standby:$GAME" "$BUCKET"

    if is_whitelisted "$GAME"; then
        state_put "deviceidle_added:$GAME" "0"
    else
        state_put "deviceidle_added:$GAME" "1"
    fi

    for P in $HOGS_USER0; do
        pkg_exists_user 0 "$P" || continue
        for OP in RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND WAKE_LOCK; do
            save_appop_once 0 "$P" "$OP"
        done
    done
}

apply_maxtouch_common() {
    try settings put global high_touch_mode 1
    try settings put secure miui_touch_boost 1
    try settings put secure game_touch_mode 1
    try settings put secure game_turbo_touch_sensitivity 3

    try settings put global input.instant_touch_response 1
    try settings put global input.touch_boost 1
    try settings put system input.touch_boost 1

    try settings put global touch.sampling_boost 1
    try settings put global touch.polling_rate 240
    try settings put global touch_sampling_rate_override 1
    try settings put global touch_response_rate 1
    try settings put global touch_rate_control 0
    try settings put global windowsmgr.support_low_latency_touch 1

    try settings put system touch_sampling_rate 240
    try settings put system touch_sampling_rate_override 1
    try settings put system devices_virtual_input_input1_polling_rate 240
    try settings put system input.high_update_rate true
    try settings put system touch_response_rate 1
    try settings put system touch_rate_control 0

    try setprop debug.input.resampling false
    try setprop debug.input.touch_prediction false
    try setprop debug.velocitytracker.strategy impulse
    try setprop debug.input.interceptdispatchtimeout_ms 0
    try setprop debug.input.multitouch_min_distance 0
    try setprop debug.input.quiet_interval 0
}

apply_roblox_priority() {
    for OP in RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND WAKE_LOCK; do
        try appops set --user 0 "$GAME" "$OP" allow
    done
    try am set-inactive "$GAME" false
    try am set-standby-bucket "$GAME" active
    if ! is_whitelisted "$GAME"; then try cmd deviceidle whitelist +"$GAME"; fi
}

apply_hog_cleanup() {
    log "Safe hog cleanup: Discord/pedometer/ChatGPT/GMS/Play Store untouched"
    for P in $HOGS_USER0; do
        pkg_exists_user 0 "$P" || continue
        try appops set --user 0 "$P" RUN_IN_BACKGROUND deny
        try appops set --user 0 "$P" RUN_ANY_IN_BACKGROUND deny
        try appops set --user 0 "$P" WAKE_LOCK deny
        case "$P" in com.miui.analytics) ;; *) try am force-stop "$P" ;; esac
    done
}

compact_roblox() {
    PID="$(pidof "$GAME" 2>/dev/null | awk '{print $1}')"
    [ -n "$PID" ] || return 0
    log "Compacting Roblox pid=$PID"
    try am compact "$PID"
}

apply_refresh_120() {
    try settings put global low_power 0
    try settings put global low_power_sticky 0
    try settings put system min_refresh_rate 120.0
    try settings put system peak_refresh_rate 120.0
    try settings put system user_refresh_rate 120.0
    try settings put system miui_refresh_rate 120
}

apply_full_profile() {
    log "FULL profile: Battery Saver OFF -> ${DOWN} + ${FULL_FPS} FPS + events=${FULL_EVENTS}"
    apply_refresh_120
    apply_maxtouch_common
    try setprop debug.inputdispatcher.max_events_per_sec "$FULL_EVENTS"
    try cmd game set --downscale "$DOWN" --fps "$FULL_FPS" "$GAME"
    try cmd game mode custom "$GAME"
    apply_roblox_priority
    apply_hog_cleanup
    compact_roblox
}

apply_saver_profile() {
    log "SAVER profile: Battery Saver ON -> ${DOWN} + ${SAVER_FPS} FPS + events=${SAVER_EVENTS}"
    apply_maxtouch_common
    try setprop debug.inputdispatcher.max_events_per_sec "$SAVER_EVENTS"
    try cmd game set --downscale "$DOWN" --fps "$SAVER_FPS" "$GAME"
    try cmd game mode custom "$GAME"
    apply_roblox_priority
}

apply_profile_for_current_power() {
    LP="$(settings get global low_power 2>/dev/null)"
    [ "$LP" = "1" ] && apply_saver_profile || apply_full_profile
}

daemon_running() {
    [ -f "$PIDFILE" ] || return 1
    PID="$(cat "$PIDFILE" 2>/dev/null)"
    [ -n "$PID" ] || return 1
    kill -0 "$PID" 2>/dev/null
}

daemon_loop() {
    echo $$ > "$PIDFILE"
    trap 'rm -f "$PIDFILE"; exit 0' INT TERM EXIT
    LAST=""
    log "v9.1 adaptive daemon started"
    while true; do
        LP="$(settings get global low_power 2>/dev/null)"
        [ -z "$LP" ] && LP="0"
        if [ "$LP" != "$LAST" ]; then
            [ "$LP" = "1" ] && apply_saver_profile || apply_full_profile
            LAST="$LP"
        fi
        sleep 10
    done
}

start_daemon() {
    if daemon_running; then
        log "daemon already running pid=$(cat "$PIDFILE" 2>/dev/null)"
        return 0
    fi
    sh "$BASE/$SELF_BASENAME" daemon_loop >/dev/null 2>&1 &
    echo $! > "$PIDFILE"
    log "daemon launched pid=$(cat "$PIDFILE" 2>/dev/null)"
}

stop_daemon_only() {
    stop_pidfile "$PIDFILE"
    # Kill only daemon_loop instances, not normal engage/stop shell.
    ME="$$"
    ps -ef 2>/dev/null | awk '/redmi_roblox_v9_1_adaptive\.sh daemon_loop/ && !/awk/ {print $2}' | while read P; do
        [ -n "$P" ] || continue
        [ "$P" = "$ME" ] && continue
        kill "$P" 2>/dev/null || true
    done
    rm -f "$PIDFILE"
}

restore_all() {
    log "Restoring saved state"
    restore_game
    for K in $PROPS_SAVE; do restore_prop "$K"; done

    for ITEM in $SETTINGS_SAVE; do
        NS="${ITEM%%:*}"; KEY="${ITEM#*:}"
        restore_setting "$NS" "$KEY"
    done

    for OP in RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND WAKE_LOCK; do
        restore_appop 0 "$GAME" "$OP"
    done

    BUCKET="$(state_get "standby:$GAME")"
    if [ -n "$BUCKET" ] && [ "$BUCKET" != "$RB_EMPTY" ]; then
        try am set-standby-bucket "$GAME" "$BUCKET"
    fi

    ADDED="$(state_get "deviceidle_added:$GAME")"
    [ "$ADDED" = "1" ] && try cmd deviceidle whitelist -"$GAME"

    for P in $HOGS_USER0; do
        for OP in RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND WAKE_LOCK; do
            restore_appop 0 "$P" "$OP"
        done
    done
}

engage() {
    mkdir -p "$BASE" 2>/dev/null
    rotate_log
    stop_legacy_daemons

    if [ ! -f "$STATE" ]; then
        log "Saving baseline state"
        save_all_once
    fi

    apply_profile_for_current_power
    start_daemon
    verify
}

stop_all() {
    stop_daemon_only
    if [ -f "$STATE" ]; then
        restore_all
        rm -f "$STATE"
    fi
    log "v9.1 stopped"
    verify
}

verify() {
    echo "=== Redmi Roblox v9.1 Adaptive VERIFY ==="
    echo "low_power=$(settings get global low_power 2>/dev/null)"
    echo "daemon_pid=$(cat "$PIDFILE" 2>/dev/null)"
    echo "max_events=$(getprop debug.inputdispatcher.max_events_per_sec 2>/dev/null)"
    echo "input_resampling=$(getprop debug.input.resampling 2>/dev/null)"
    echo "touch_prediction=$(getprop debug.input.touch_prediction 2>/dev/null)"
    echo "velocitytracker=$(getprop debug.velocitytracker.strategy 2>/dev/null)"
    echo ""
    echo "## GAME"
    cmd game list-modes "$GAME" 2>&1
    dumpsys game 2>/dev/null | grep -A6 -i "$GAME"
    echo ""
    echo "## SURFACEFLINGER"
    dumpsys SurfaceFlinger 2>/dev/null | grep -A3 -B3 -E 'GameFrameRateOverrides|10490|renderRate=|activeMode=' | head -80
    echo ""
    echo "## ROBLOX APP OPS"
    appops get "$GAME" RUN_IN_BACKGROUND 2>&1
    appops get "$GAME" RUN_ANY_IN_BACKGROUND 2>&1
    appops get "$GAME" WAKE_LOCK 2>&1
    echo ""
    echo "## SAFETY"
    echo "background_process_limit=$(settings get global background_process_limit 2>/dev/null)"
    echo "Does not touch: Discord, pedometer, ChatGPT, GMS, Play Store"
}

case "${1:-engage}" in
    engage|start|on) engage ;;
    daemon_loop) daemon_loop ;;
    stop|off|restore) stop_all ;;
    full) [ -f "$STATE" ] || save_all_once; apply_full_profile; verify ;;
    saver) [ -f "$STATE" ] || save_all_once; apply_saver_profile; verify ;;
    verify|status) verify ;;
    killold) stop_legacy_daemons; stop_daemon_only; echo "daemons stopped" ;;
    *) echo "Usage: sh $0 engage|stop|verify|full|saver|killold" ;;
esac

exit 0
