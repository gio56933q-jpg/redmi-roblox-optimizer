#!/system/bin/sh
# =============================================================================
# RedmiBoost Diagnostic Script — v1.0
# Device  : Redmi 15 4G / HyperOS 3 / Android 16 / Snapdragon 685
# Access  : Shizuku UID 2000 — READ ONLY — no state changes
# Output  : /storage/emulated/0/Download/rb_diag_<timestamp>.txt
# Usage   : Run with Roblox ACTIVE and inside a game for full renderer data
# =============================================================================

OUTFILE="/storage/emulated/0/Download/rb_diag_$(date +%Y%m%d_%H%M%S).txt"
RBX_PKG="com.roblox.client"

# Stream to both file and stdout
exec > "$OUTFILE" 2>&1

hr() { printf '\n%.0s' {1..1}; printf '=%.0s' {1..72}; printf '\n'; }
sec() { hr; printf "[ %s ]\n" "$1"; hr; }
sub() { printf "\n--- %s ---\n" "$1"; }

sec "REDMIBOOST DIAGNOSTIC REPORT"
printf "Timestamp  : %s\n" "$(date)"
printf "Output     : %s\n" "$OUTFILE"
printf "Running UID: %s\n" "$(id)"
printf "Shell      : %s\n" "$SHELL"
printf "NOTE       : Run this with Roblox active inside a game for full renderer data\n"

# =============================================================================
sec "SECTION 1 — ROBLOX PROCESS STATE"
# =============================================================================

sub "1.1 Roblox PID"
RBX_PID=$(pidof "$RBX_PKG" 2>/dev/null)
if [ -z "$RBX_PID" ]; then
    printf "STATUS : Roblox is NOT running\n"
    printf "WARNING: Sections 2, 3, 7.1 will be empty or incomplete\n"
    printf "         Rerun this script with Roblox active in a game\n"
else
    printf "STATUS : Roblox is RUNNING\n"
    printf "PID    : %s\n" "$RBX_PID"
    printf "UID    : %s\n" "$(cat /proc/$RBX_PID/status 2>/dev/null | grep '^Uid:' | awk '{print $2}' || echo 'unreadable')"
fi

sub "1.2 Roblox App Standby Bucket"
dumpsys usagestats "$RBX_PKG" 2>/dev/null \
    | grep -E "bucket=|reason=|lastPred|nextEstimated|idle=" \
    | head -n 10
printf "\nBucket values: 5=RESTRICTED 10=RARE 20=FREQUENT 30=WORKING_SET 40=ACTIVE\n"
printf "reason=d means HyperOS set bucket dynamically — will drift back regardless of am set-standby-bucket\n"

sub "1.3 Roblox AppOps State"
for OP in RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND WAKE_LOCK START_FOREGROUND; do
    printf "  %-35s : %s\n" "$OP" "$(appops get $RBX_PKG $OP 2>/dev/null || echo 'FAILED')"
done

sub "1.4 Roblox DeviceIdle Whitelist"
cmd deviceidle whitelist 2>/dev/null | grep -i "roblox" \
    || printf "  com.roblox.client NOT in deviceidle whitelist\n"

sub "1.5 Roblox Network Policy"
dumpsys netpolicy 2>/dev/null | grep -A 5 "$RBX_PKG" \
    || printf "  No netpolicy entry found for Roblox\n"

# =============================================================================
sec "SECTION 2 — ROBLOX NATIVE RENDERER IDENTIFICATION"
# =============================================================================
printf "Critical section. Answers: hardware vs software, GLES vs Vulkan, ANGLE vs native.\n\n"

sub "2.1 /proc/<pid>/maps — Loaded Graphics Libraries"
if [ -z "$RBX_PID" ]; then
    printf "SKIPPED: Roblox not running\n"
else
    MAPS_OUT=$(cat /proc/$RBX_PID/maps 2>/dev/null \
        | grep -iE "libGLES|libvulkan|swiftshader|angle|adreno|kgsl|libEGL|egl_adreno|vulkan_adreno" \
        | sort -u)
    if [ -z "$MAPS_OUT" ]; then
        MAPS_ERR=$(cat /proc/$RBX_PID/maps 2>&1 | head -n 1)
        printf "RESULT : No output\n"
        printf "ERROR  : %s\n" "$MAPS_ERR"
        printf "MEANING: SELinux likely blocked /proc/<pid>/maps at UID 2000\n"
    else
        printf "%s\n" "$MAPS_OUT"
        printf "\nINTERPRETATION:\n"
        echo "$MAPS_OUT" | grep -qi "swiftshader" \
            && printf "  [!!] SwiftShader DETECTED — software rendering is CONFIRMED for Roblox\n" \
            || printf "  [OK] SwiftShader NOT found\n"
        echo "$MAPS_OUT" | grep -qiE "adreno|kgsl" \
            && printf "  [OK] Adreno/KGSL DETECTED — hardware rendering confirmed\n" \
            || printf "  [??] Adreno/KGSL NOT found in this grep — may still be hardware\n"
        echo "$MAPS_OUT" | grep -qi "angle" \
            && printf "  [!!] ANGLE library DETECTED — ANGLE is actually loaded for Roblox\n" \
            || printf "  [  ] ANGLE NOT in mapped libraries\n"
        echo "$MAPS_OUT" | grep -qi "vulkan" \
            && printf "  [!!] Vulkan library DETECTED — Roblox may be using Vulkan natively\n" \
            || printf "  [  ] Vulkan NOT found in mapped libraries\n"
    fi
fi

sub "2.2 logcat — EGL/Renderer Init Lines (last 5 minutes)"
printf "Filtering logcat for EGL, Vulkan, GLES, Adreno, SwiftShader, ANGLE, KGSL...\n\n"
logcat -d -t 300 2>/dev/null \
    | grep -iE "egl|vulkan|gles|swiftshader|adreno|angle|kgsl|opengl|renderer|grdevice|rhi|graphicsdevice|vkdevice" \
    | grep -v "^-\|AudioFlinger\|MediaCodec\|camera\|bluetooth\|wifi" \
    | tail -n 80
printf "\nINTERPRETATION:\n"
printf "  Look for: Qualcomm EGL version strings, kgsl_cl, Adreno = hardware confirmed\n"
printf "  Look for: ANGLE, SwiftShader, Mesa = non-hardware path\n"
printf "  Look for: vkCreateDevice, VkPhysicalDevice = Roblox using Vulkan natively\n"
printf "  No output = Roblox suppresses EGL logs in release build (common)\n"

sub "2.3 logcat — Roblox PID Specific (if PID available)"
if [ -n "$RBX_PID" ]; then
    logcat -d --pid="$RBX_PID" 2>/dev/null \
        | grep -iE "egl|vulkan|gles|swiftshader|adreno|angle|kgsl|renderer|backend|rhi" \
        | tail -n 40
    printf "\nTotal Roblox-PID log lines (last dump): %s\n" \
        "$(logcat -d --pid=$RBX_PID 2>/dev/null | wc -l)"
else
    printf "SKIPPED: Roblox not running\n"
fi

sub "2.4 dumpsys gpu — GPU Client Activity"
printf "Looking for UID 10490 (Roblox) in GPU client list...\n\n"
GPU_DUMP=$(dumpsys gpu 2>/dev/null)
if [ -z "$GPU_DUMP" ]; then
    printf "RESULT : dumpsys gpu returned empty — service may not be accessible at UID 2000\n"
else
    printf "%s\n" "$GPU_DUMP" | grep -iE "10490|roblox|uid|memory|allocation|client|driver|version" | head -n 40
    printf "\n--- Full gpu dump (first 60 lines) ---\n"
    printf "%s\n" "$GPU_DUMP" | head -n 60
fi

sub "2.5 dumpsys SurfaceFlinger — Roblox Surface Layer"
printf "Looking for Roblox layer composition type...\n\n"
SF_DUMP=$(dumpsys SurfaceFlinger 2>/dev/null)
printf "%s\n" "$SF_DUMP" \
    | grep -iE "com.roblox|10490|GameFrameRateOverride|gameModeOverride|gameDefaultOverride" \
    | head -n 20
printf "\n--- Roblox layer detail ---\n"
printf "%s\n" "$SF_DUMP" | grep -A 15 "com.roblox.client" | head -n 40
printf "\nINTERPRETATION:\n"
printf "  Composition type 'Device' or 'HWC'  = GPU composited = display sees GPU output\n"
printf "  Composition type 'Client'             = CPU fallback composition\n"

# =============================================================================
sec "SECTION 3 — PROCESS MEMORY AND ZRAM PRESSURE"
# =============================================================================

sub "3.1 Roblox Memory Detail (dumpsys meminfo)"
if [ -n "$RBX_PID" ]; then
    dumpsys meminfo "$RBX_PKG" 2>/dev/null | head -n 40
else
    printf "SKIPPED: Roblox not running\n"
fi

sub "3.2 Overall Memory Pressure"
dumpsys meminfo 2>/dev/null \
    | grep -E "Total RAM|Free RAM|Used RAM|Lost RAM|ZRAM|zram|Cached|Slab" \
    | head -n 15

# =============================================================================
sec "SECTION 4 — ANGLE AND GRAPHICS DRIVER INSTALLATION"
# =============================================================================
printf "Determines whether ANGLE is present on this device at all.\n"
printf "If absent, all angle_gl_driver_* settings keys are permanently inert.\n\n"

sub "4.1 ANGLE APEX Module"
ls -la /apex/com.android.angle/ 2>&1
ls -la /apex/com.android.angle/lib64/ 2>&1
ls -la /apex/com.android.angle/lib/ 2>&1

sub "4.2 System EGL Driver Directory"
ls -la /system/lib64/egl/ 2>&1
ls -la /system/lib/egl/ 2>&1

sub "4.3 Vendor EGL Driver Directory"
ls -la /vendor/lib64/egl/ 2>&1
ls -la /vendor/lib/egl/ 2>&1

sub "4.4 ANGLE Package (if installed as APK)"
pm list packages 2>/dev/null | grep -iE "angle|glesv2" \
    || printf "  No ANGLE-related packages found via pm list\n"

sub "4.5 Updatable Game Driver Location"
ls -la /apex/com.android.gki.* 2>/dev/null | head -n 10
ls -la /data/app/ 2>/dev/null | grep -iE "angle|gdriver|gamedriver" | head -n 10

printf "\nINTERPRETATION:\n"
printf "  If /apex/com.android.angle/ is absent: ANGLE does not exist on this device\n"
printf "  All angle_gl_driver_* settings writes are then permanently non-functional\n"
printf "  This is the most likely explanation for why ANGLE keys had no effect\n"

# =============================================================================
sec "SECTION 5 — ANGLE AND DRIVER SETTINGS KEYS (READBACK)"
# =============================================================================

sub "5.1 ANGLE Global Selection Keys"
for KEY in \
    angle_gl_driver_selection_pkgs \
    angle_gl_driver_selection_values \
    angle_gl_driver_selection_value \
    angle_gl_driver_all_apps \
    angle_allowlist \
    angle_debug_package \
    angle_gl_driver_impl \
    angle_gl_developer_opt_in_apps; do
    VAL=$(settings get global "$KEY" 2>/dev/null)
    printf "  %-45s : %s\n" "$KEY" "${VAL:-null}"
done

sub "5.2 Game Driver and Updatable Driver Keys"
for KEY in \
    game_driver_all_apps \
    game_driver_opt_in_apps \
    game_driver_opt_out_apps \
    updatable_driver_production_opt_in_apps \
    updatable_driver_production_opt_out_apps \
    updatable_driver_all_apps \
    updatable_driver_sphal_libraries; do
    VAL=$(settings get global "$KEY" 2>/dev/null)
    printf "  %-50s : %s\n" "$KEY" "${VAL:-null}"
done

sub "5.3 Additional Graphics Settings"
for KEY in \
    enable_gpu_debug_layers \
    gpu_debug_layers \
    gpu_debug_layer_app \
    enable_angle_choosing \
    game_mode_intervention_list_version; do
    VAL=$(settings get global "$KEY" 2>/dev/null)
    printf "  %-45s : %s\n" "$KEY" "${VAL:-null}"
done

# =============================================================================
sec "SECTION 6 — GAMEMANAGER STATE"
# =============================================================================

sub "6.1 cmd game help (full output)"
cmd game help 2>&1

sub "6.2 cmd game list-configs for Roblox"
cmd game list-configs "$RBX_PKG" 2>&1

sub "6.3 cmd game mode current state"
cmd game mode "$RBX_PKG" 2>&1

sub "6.4 Hidden ANGLE flags probe (read error messages carefully)"
printf "\nProbing cmd game set --angle:\n"
cmd game set --angle true "$RBX_PKG" 2>&1
printf "\nProbing cmd game set --use-angle:\n"
cmd game set --use-angle true "$RBX_PKG" 2>&1
printf "\nProbing cmd game set --angle=1:\n"
cmd game set --angle=1 "$RBX_PKG" 2>&1
printf "\nProbing cmd game set --driver:\n"
cmd game set --driver angle "$RBX_PKG" 2>&1
printf "\nINTERPRETATION:\n"
printf "  'Unknown option: --angle'  = parser recognizes the flag, command structure exists\n"
printf "  Generic usage error        = flag is unknown to this build's cmd game parser\n"

sub "6.5 dumpsys game — Roblox Game Config"
dumpsys game 2>/dev/null | grep -A 20 -i "roblox\|Use Angle\|GamePackage\|10490" | head -n 60

sub "6.6 SurfaceFlinger GameFrameRateOverrides"
dumpsys SurfaceFlinger 2>/dev/null \
    | grep -iE "GameFrameRateOverride|gameModeOverride|gameDefaultOverride|10490" \
    | head -n 10

# =============================================================================
sec "SECTION 7 — HYPEROS EXCLUSIVE SERVICES"
# =============================================================================

sub "7.1 MiuiForceVkService — Full Dump"
printf "This is a HyperOS-only service. May control per-app Vulkan forcing.\n\n"
dumpsys MiuiForceVkService 2>&1 | head -n 80
printf "\n--- cmd interface probe ---\n"
cmd MiuiForceVkService help 2>&1
cmd MiuiForceVkService list 2>&1
cmd MiuiForceVkService status 2>&1
cmd MiuiForceVkService status "$RBX_PKG" 2>&1

sub "7.2 FramerateFineControlService — Full Dump"
printf "HyperOS framerate control layer. May impose policies independent of GameManager.\n\n"
dumpsys FramerateFineControlService 2>&1 | head -n 80
printf "\n--- cmd interface probe ---\n"
cmd FramerateFineControlService help 2>&1
cmd FramerateFineControlService status 2>&1

sub "7.3 SchedBoostService"
dumpsys SchedBoostService 2>&1 | head -n 40

sub "7.4 MiuiBoosterService"
dumpsys miuiboosterservice 2>&1 | head -n 40

sub "7.5 HyperOSCustFeatureResolve"
dumpsys HyperOSCustFeatureResolve 2>&1 | head -n 40

sub "7.6 ProcessManager"
dumpsys ProcessManager 2>&1 | head -n 40

sub "7.7 turbosched props"
for PROP in \
    persist.sys.turbosched.enable \
    persist.sys.turbosched.enable_v2 \
    persist.sys.turbosched.coreApp.enable \
    persist.sys.turbosched.policy_list \
    persist.sys.turbosched.gaea.enable; do
    printf "  %-50s : %s\n" "$PROP" "$(getprop $PROP 2>/dev/null)"
done

# =============================================================================
sec "SECTION 8 — SURFACEFLINGER AND DISPLAY PIPELINE"
# =============================================================================

sub "8.1 Active Display Mode"
dumpsys SurfaceFlinger 2>/dev/null \
    | grep -iE "activeMode|vsyncRate|renderRate|refreshRate|fps|displayId|color mode" \
    | head -n 20

sub "8.2 Phase Offsets and Frame Timing"
dumpsys SurfaceFlinger 2>/dev/null \
    | grep -iE "phase|offset|duration|late\.|early\.|vsync|transaction" \
    | head -n 30

sub "8.3 SurfaceFlinger Props (current values)"
for PROP in \
    debug.sf.disable_backpressure \
    debug.sf.enable_gl_backpressure \
    debug.sf.latch_unsignaled \
    debug.sf.auto_latch_unsignaled \
    debug.sf.use_phase_offsets_as_durations \
    debug.sf.use_phase_offsets_as_offsets \
    debug.sf.predict_hwc_composition_strategy \
    debug.sf.ignore_present_fences \
    debug.sf.set_idle_timer_ms \
    debug.sf.layer_caching_enabled \
    debug.sf.compbypass.enable; do
    printf "  %-50s : %s\n" "$PROP" "$(getprop $PROP 2>/dev/null)"
done

sub "8.4 HWUI Props (current values)"
for PROP in \
    debug.hwui.renderer \
    debug.hwui.render_backend \
    debug.hwui.use_hint_manager \
    debug.hwui.skip_empty_damage \
    debug.hwui.use_buffer_age \
    debug.hwui.use_partial_updates \
    debug.hwui.use_gpu_pixel_buffers \
    debug.hwui.render_dirty_regions \
    debug.renderengine.backend; do
    printf "  %-50s : %s\n" "$PROP" "$(getprop $PROP 2>/dev/null)"
done

# =============================================================================
sec "SECTION 9 — INPUT PIPELINE STATE"
# =============================================================================

sub "9.1 Input Props (current values)"
for PROP in \
    debug.velocitytracker.strategy \
    debug.input.resampling \
    debug.input.touch_prediction \
    debug.input.touch_smooth \
    debug.input.multitouch_min_distance \
    debug.input.quiet_interval \
    debug.input.virtualkey_quiet_time \
    debug.input.filter \
    debug.inputdispatcher.max_events_per_sec \
    debug.inputdispatcher.vsync \
    debug.inputreader.lsq2_enabled \
    debug.tp.grip_enable \
    sys.tp.grip_enable; do
    printf "  %-50s : %s\n" "$PROP" "$(getprop $PROP 2>/dev/null)"
done

sub "9.2 HyperOS Touch Settings Keys"
for KEY in \
    input.instant_touch_response \
    input.touch_boost \
    touch.sampling_boost \
    touch_sampling_rate \
    touch_sampling_rate_override \
    devices_virtual_input_input1_polling_rate \
    pointer_speed; do
    GVAL=$(settings get global "$KEY" 2>/dev/null)
    SVAL=$(settings get system "$KEY" 2>/dev/null)
    printf "  %-45s global:%-12s system:%s\n" "$KEY" "${GVAL:-null}" "${SVAL:-null}"
done

sub "9.3 InputDispatcher Live State"
dumpsys input 2>/dev/null \
    | grep -iE "ANR|latency|dispatch|focus|roblox|timeout|drop" \
    | head -n 30

sub "9.4 Touch Feature HAL"
dumpsys touchfeature_v2-hal-1-0 2>&1 | head -n 30
printf "\n"
cmd touchfeature help 2>&1 | head -n 10

# =============================================================================
sec "SECTION 10 — SYSTEM PERFORMANCE STATE"
# =============================================================================

sub "10.1 persist.sys.force_sw_gles"
printf "  persist.sys.force_sw_gles : %s\n" "$(getprop persist.sys.force_sw_gles 2>/dev/null)"
printf "  persist.graphics.egl      : %s\n" "$(getprop persist.graphics.egl 2>/dev/null)"
printf "  ro.kernel.qemu.gles       : %s\n" "$(getprop ro.kernel.qemu.gles 2>/dev/null)"
printf "  debug.egl.hw              : %s\n" "$(getprop debug.egl.hw 2>/dev/null)"
printf "  debug.vulkan.enabled      : %s\n" "$(getprop debug.vulkan.enabled 2>/dev/null)"
printf "  ro.hardware.egl           : %s\n" "$(getprop ro.hardware.egl 2>/dev/null)"
printf "  ro.hardware.vulkan        : %s\n" "$(getprop ro.hardware.vulkan 2>/dev/null)"
printf "  ro.hwui.use_vulkan        : %s\n" "$(getprop ro.hwui.use_vulkan 2>/dev/null)"

sub "10.2 Performance Profile Props"
printf "  persist.sys.perf_turbo_type            : %s\n" "$(getprop persist.sys.perf_turbo_type)"
printf "  persist.sys.perf_scenario_recognition  : %s\n" "$(getprop persist.sys.perf_scenario_recognition.enable)"
printf "  persist.sys.computility.cpulevel       : %s\n" "$(getprop persist.sys.computility.cpulevel)"
printf "  persist.sys.computility.gpulevel       : %s\n" "$(getprop persist.sys.computility.gpulevel)"
printf "  persist.vendor.dfps.level              : %s\n" "$(getprop persist.vendor.dfps.level)"
printf "  persist.vendor.power.dfps.level        : %s\n" "$(getprop persist.vendor.power.dfps.level)"
printf "  persist.vendor.extreme.mode            : %s\n" "$(getprop persist.vendor.extreme.mode)"

sub "10.3 Battery Saver State"
printf "  low_power                  : %s\n" "$(settings get global low_power 2>/dev/null)"
printf "  low_power_sticky           : %s\n" "$(settings get global low_power_sticky 2>/dev/null)"
printf "  power_saver_mode           : %s\n" "$(settings get global power_saver_mode 2>/dev/null)"
printf "  battery saver full check:\n"
cmd power query-mode 2>&1
cmd power query-saver 2>&1

sub "10.4 CPU Load (cpuinfo)"
dumpsys cpuinfo 2>/dev/null | head -n 20

sub "10.5 CPU Frequencies at time of test"
for N in 0 1 2 3 4 5 6 7; do
    FREQ=$(cat /sys/devices/system/cpu/cpu${N}/cpufreq/scaling_cur_freq 2>/dev/null \
           || echo "no_access")
    printf "  cpu%s : %s\n" "$N" "$FREQ"
done

sub "10.6 Thermal Service State"
dumpsys thermalservice 2>/dev/null \
    | grep -iE "temperature|throttle|status|override|level|current" \
    | head -n 30

# =============================================================================
sec "SECTION 11 — ROBLOX GFXINFO SNAPSHOT"
# =============================================================================

sub "11.1 Current gfxinfo (if Roblox running)"
if [ -n "$RBX_PID" ]; then
    dumpsys gfxinfo "$RBX_PKG" 2>/dev/null | head -n 80
else
    printf "SKIPPED: Roblox not running\n"
fi

# =============================================================================
sec "SECTION 12 — WRITABLE PROP CAPABILITY AUDIT"
# =============================================================================
printf "Tests whether key props are writable at UID 2000 right now.\n"
printf "Each test writes a benign test value then immediately restores.\n\n"

_cap_test() {
    local PROP="$1"
    local TEST_VAL="$2"
    local ORIG
    ORIG=$(getprop "$PROP" 2>/dev/null)
    setprop "$PROP" "$TEST_VAL" 2>/dev/null
    local RESULT
    RESULT=$(getprop "$PROP" 2>/dev/null)
    if [ "$RESULT" = "$TEST_VAL" ]; then
        printf "  WRITABLE  : %s (was: %s)\n" "$PROP" "${ORIG:-empty}"
        # Restore
        if [ -z "$ORIG" ]; then
            setprop "$PROP" "" 2>/dev/null
        else
            setprop "$PROP" "$ORIG" 2>/dev/null
        fi
    else
        printf "  READONLY  : %s (current: %s)\n" "$PROP" "${RESULT:-empty}"
    fi
}

_cap_test "debug.velocitytracker.strategy" "impulse"
_cap_test "debug.input.resampling" "false"
_cap_test "debug.inputdispatcher.max_events_per_sec" "480"
_cap_test "debug.hwui.use_hint_manager" "true"
_cap_test "debug.sf.disable_backpressure" "0"
_cap_test "debug.sf.latch_unsignaled" "0"
_cap_test "debug.vulkan.enabled" "1"
_cap_test "persist.sys.perf_turbo_type" "19"
_cap_test "debug.hwui.use_buffer_age" "true"
_cap_test "debug.hwui.skip_empty_damage" "true"

# =============================================================================
sec "SECTION 13 — SETTINGS WRITABILITY AUDIT"
# =============================================================================
printf "Tests whether key settings are writable at UID 2000 right now.\n\n"

_settings_test() {
    local NS="$1"
    local KEY="$2"
    local TEST_VAL="$3"
    local ORIG
    ORIG=$(settings get "$NS" "$KEY" 2>/dev/null)
    settings put "$NS" "$KEY" "$TEST_VAL" 2>/dev/null
    local RESULT
    RESULT=$(settings get "$NS" "$KEY" 2>/dev/null)
    if [ "$RESULT" = "$TEST_VAL" ]; then
        printf "  WRITABLE  : %s/%s (was: %s)\n" "$NS" "$KEY" "${ORIG:-null}"
        # Restore
        if [ "$ORIG" = "null" ] || [ -z "$ORIG" ]; then
            settings delete "$NS" "$KEY" 2>/dev/null
        else
            settings put "$NS" "$KEY" "$ORIG" 2>/dev/null
        fi
    else
        printf "  BLOCKED   : %s/%s (got: %s)\n" "$NS" "$KEY" "${RESULT:-null}"
    fi
}

_settings_test global "angle_gl_driver_selection_pkgs" "com.roblox.client"
_settings_test global "angle_gl_driver_all_apps" "1"
_settings_test global "angle_allowlist" "com.roblox.client"
_settings_test global "angle_debug_package" "com.roblox.client"
_settings_test global "game_driver_all_apps" "1"
_settings_test global "updatable_driver_production_opt_out_apps" "__rb_test__"
_settings_test global "background_process_limit" "-1"
_settings_test system "touch_sampling_rate" "240"
_settings_test global "input.instant_touch_response" "1"

# =============================================================================
sec "SECTION 14 — BUILD AND DEVICE BASELINE"
# =============================================================================

sub "14.1 Core Build Props"
for PROP in \
    ro.build.version.release \
    ro.build.version.sdk \
    ro.build.fingerprint \
    ro.product.device \
    ro.product.model \
    ro.product.marketname \
    ro.board.platform \
    ro.hardware \
    ro.hardware.egl \
    ro.hardware.vulkan \
    ro.opengles.version \
    ro.sf.lcd_density \
    ro.surface_flinger.game_default_frame_rate_override \
    ro.surface_flinger.enable_frame_rate_override \
    persist.sys.force_sw_gles; do
    printf "  %-55s : %s\n" "$PROP" "$(getprop $PROP 2>/dev/null)"
done

sub "14.2 Dalvik / ART Props"
for PROP in \
    dalvik.vm.heapsize \
    dalvik.vm.heapgrowthlimit \
    dalvik.vm.heapmaxfree \
    dalvik.vm.heaptargetutilization \
    dalvik.vm.usejit \
    dalvik.vm.useartservice; do
    printf "  %-50s : %s\n" "$PROP" "$(getprop $PROP 2>/dev/null)"
done

# =============================================================================
sec "REPORT COMPLETE"
# =============================================================================
printf "Output saved to: %s\n" "$OUTFILE"
printf "Timestamp      : %s\n" "$(date)"
printf "\nNext steps:\n"
printf "  1. Check Section 2.1 (/proc/maps) and 2.2 (logcat) for renderer verdict\n"
printf "  2. Check Section 4.1 (ANGLE APEX) — if absent, close ANGLE path permanently\n"
printf "  3. Check Section 7.1 (MiuiForceVkService) for cmd interface\n"
printf "  4. Check Section 7.2 (FramerateFineControlService) for policy conflicts\n"
printf "  5. Check Section 12 (prop writability) for any newly blocked props\n"
printf "  6. Share this file for analysis\n"

exit 0
