You are maintaining a small shell-script project for Redmi 15 4G / HyperOS 3 / Android 16 / Snapdragon 685 / Adreno 610 / 6 GB RAM. Access is Shizuku UID 2000 only. No root.

Your job is NOT to invent new Android tweaks. Your job is to cleanly maintain, audit, and version the script based on confirmed device logs.

Read all docs in /docs, /logs, and the current script in /scripts.

Project goal:
Maintain a safe Roblox optimization script for com.roblox.client that applies the current confirmed best profile, supports A/B test modes, has proper restore logic, and avoids fake/root-only commands.

Current confirmed best profile:
- Battery Saver off
- 120 Hz refresh settings
- GameManager custom mode
- cmd game set --downscale 0.25 --fps 120 com.roblox.client
- SurfaceFlinger readback should show {10490, 120 0}
- debug.inputdispatcher.max_events_per_sec=9999
- debug.input.resampling=false
- debug.input.touch_prediction=false
- debug.velocitytracker.strategy=impulse
- debug.tp.grip_enable=90
- cmd deviceidle whitelist +com.roblox.client
- am set-inactive com.roblox.client false
- am set-standby-bucket com.roblox.client active
- appops set com.roblox.client RUN_IN_BACKGROUND allow
- appops set com.roblox.client RUN_ANY_IN_BACKGROUND allow
- appops set com.roblox.client WAKE_LOCK allow
- compact Roblox PID with am compact only if PID exists
- safe hog cleanup only; do not touch Discord, cloned Discord, pedometer, ChatGPT, GMS, or Play Store

Important diagnostic facts:
- Roblox UID observed: 10490
- SurfaceFlinger confirms {10490, 120 0}
- Active display mode can be 120 Hz
- ANGLE injection path is closed/unusable for Roblox on this build
- Stable/Pre-release Game Driver unsupported
- device_config writes are blocked
- MiuiForceVkService and FramerateFineControlService fail with Failed transaction
- TouchFeature service is not accessible
- Thermal and ZRAM/page faults are the remaining major bottlenecks
- background_process_limit=2 previously broke ChatGPT/Recents and is banned

Hard exclusions:
Do not add root-only /sys writes, /proc writes, CPU/GPU governor edits, IRQ pinning, ZRAM/sysctl tuning, cgroup/uclamp edits, raw service calls, device_config put/delete, thermal spoofing, PowerKeeper clear/disable, background_process_limit=2, am kill-all, GMS/Play Store modifications, ANGLE keys, developer_graphics_driver keys, fake 144/240 FPS settings, or random SettingsProvider pollution.

Task:
Create v9.2 from the current script.

Requirements:
1. Preserve no-root UID 2000 compatibility.
2. Add modes:
   - engage: current best full profile
   - saver: 60 FPS + max_events 480
   - events480
   - events1600
   - events9999
   - scale025
   - scale035
   - grip90
   - grip120
   - grip150
   - verify
   - stop/restore
3. Save previous state before changing props/settings/appops when practical.
4. Restore only what the script changed.
5. Use safe PID-file daemon logic only. Do not use broad pkill patterns that can kill the current shell.
6. Reapply Roblox standby active and deviceidle whitelist periodically while daemon is running.
7. Include exact readback commands in verify:
   - id
   - low_power
   - cmd game list-modes com.roblox.client
   - SurfaceFlinger GameFrameRateOverrides/renderRate/activeMode
   - max_events
   - input resampling/prediction/velocitytracker/grip
   - deviceidle whitelist
   - appops
   - standby bucket
   - gfxinfo summary if Roblox is running
8. Add README usage instructions for aShell You / AXManager.
9. Add CHANGELOG entry explaining v9.2 changes.
10. Do not make claims in comments that a command is confirmed unless docs/logs prove it.

Output:
- Modify the repo files.
- Show a concise diff summary.
- Point out any risky command you removed or refused to include.
