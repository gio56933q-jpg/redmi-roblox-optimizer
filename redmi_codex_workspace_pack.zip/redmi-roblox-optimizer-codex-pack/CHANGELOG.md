# Changelog

## v9.2 planned

- Base full profile on confirmed current best state:
  - 0.25 downscale
  - 120 FPS
  - 120 Hz
  - max_events=9999
  - resampling=false
  - touch_prediction=false
  - velocitytracker=impulse
  - debug.tp.grip_enable=90
- Add A/B modes:
  - events480
  - events1600
  - events9999
  - scale025
  - scale035
  - grip90
  - grip120
  - grip150
- Add explicit Roblox AppOps allow.
- Add DeviceIdle whitelist handling.
- Reapply standby active periodically in daemon.
- Keep safe hog cleanup only.
- Remove/avoid ANGLE, game-driver forcing, PowerKeeper, device_config, thermal spoofing, fake FPS keys, and root-only commands.

## v9.1

- Adaptive Battery Saver behavior:
  - Battery Saver off: full profile
  - Battery Saver on: saver profile
- Safer PID-file daemon logic compared with broad pkill.

## v9

- First adaptive daemon attempt.
- Had confusion around old profile state and broad process killing.
