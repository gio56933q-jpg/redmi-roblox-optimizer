# Current Device Profile

| Item | Value |
|---|---|
| Device | Redmi 15 4G |
| OS | HyperOS 3 / Android 16 |
| SoC | Snapdragon 685 / Qualcomm SM6225 |
| GPU | Adreno 610 |
| RAM | 6 GB |
| Access | Shizuku / ADB shell only |
| UID | 2000(shell) |
| SELinux | Enforcing |
| Target app | com.roblox.client |
| Roblox UID observed | 10490 |
| Main game | Roblox / The Strongest Battlegrounds |

Confirmed shell identity from AXManager and aShell You:

```text
uid=2000(shell) gid=2000(shell) context=u:r:shell:s0
getenforce = Enforcing
```

No root is available. Do not propose root-only commands.
