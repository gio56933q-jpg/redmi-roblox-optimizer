# Memory File — Redmi HyperOS / Roblox Optimization Workflow

---

## 1. Response Style

- Direct, critical, practical.
- Separate confirmed from unconfirmed. Label clearly.
- Give exact commands when requested.
- For capability tests: do NOT hide errors — use real read-back, not exit code.
- For final scripts: use safe wrappers (`2>/dev/null || true`) where appropriate, not everywhere by default.
- Give warnings when a command can break restore state or app behavior.
- No excessive praise. No padding. No softening of corrections.

---

## 2. Current Device and Access

| Property | Value |
|---|---|
| Device | Redmi 15 4G |
| Codename | creek / missi |
| SoC | Qualcomm SM6225 (Snapdragon 685) |
| CPU topology | 8-core: 4×A73 + 4×A53 (treat as standard 8-core unless logs prove otherwise) |
| GPU | Adreno 610 |
| RAM | 6 GB (use 8 GB only if explicitly proven by logs) |
| Android | 16 (SDK 36) |
| OS | HyperOS OS3.0.10.0.WBOMIXM |
| Kernel | 5.15 |
| Build | BP2A.250605.031.A3 |
| Security patch | 2026-02-01 |
| Access | **Shizuku UID 2000 (shell). No root. No su.** |
| Script runner | QuickShell / Axeron via AXManager |
| Density | `ro.sf.lcd_density=450` |
| Resolution | 1080×2340 |
| Default/idle FPS | 48 Hz |
| Peak display | Panel may advertise up to 144 Hz in SF dumps; confirmed practical Roblox target is 120 Hz. Use 120 Hz for scripts unless explicitly testing 144. |
| Target app | `com.roblox.client` (Roblox, UID 10490) |
| Main game | Roblox / The Strongest Battlegrounds |

**Confirmed renderer state (from getprop):**
```
debug.hwui.renderer=skiavkthreaded
debug.renderengine.backend=skiavkthreaded
debug.vulkan.enabled=1
persist.sys.force_sw_gles=1          ← immutable, root-only to change
```

---

## 3. Main Goal

Smoother Roblox gameplay within no-root UID 2000 constraints:
- Stable FPS at 120 Hz target
- Lower touch-to-action latency
- Reduced jank and kswapd0 pressure spikes
- Lower ping variance
- No background app kills (especially Discord clones)
- No root required

---

## 4. Hard Constraints

Never suggest unless explicitly requested:

| Constraint | Reason |
|---|---|
| `ro.*` setprops | Immutable from UID 2000 — period |
| `persist.sys.force_sw_gles` | Confirmed `=1`, immutable, root-only |
| `/sys` writes (CPU/GPU governor, freq, IRQ) | Requires UID 0 |
| `/proc/sys/vm/*` sysctl writes | Requires UID 0 |
| `device_config put/delete` | Blocked on this HyperOS build at UID 2000 |
| `cmd thermalservice override-status` (any value) | Rejected as thermal spoofing — do not use in main scripts |
| `am kill-all` | Too aggressive, breaks background apps |
| `background_process_limit=2` | Confirmed broken ChatGPT and Recents — banned |
| `pm disable-user` / `pm grant/revoke` | SecurityException on this build |
| `raw service call` (any) | Unsafe, effect unverified or confirmed non-functional |
| `miui.downscale` for Roblox on this device | Resolved to `scale=1.0` on 1080p — no effect |
| GMS / Play Store modifications | Off limits |
| Fake Hz props (240+) | Not supported by display hardware. 144 may appear in SF dumps but do not set as default target. |
| `cmd power set-adaptive-power-saver-enabled false` | Only use if safe read/restore exists |
| `wm density reset` in daemon restore | Causes permanent broken UI on unclean daemon exit |

---

## 5. Confirmed Working Current Commands (UID 2000)

**Game Manager API — confirmed working:**
```sh
cmd game mode custom com.roblox.client
cmd game set --downscale 0.35 --fps 120 com.roblox.client   # engage
cmd game set --downscale 0.3  --fps 120 com.roblox.client   # aggressive
```
SurfaceFlinger confirmed: Roblox UID 10490 shows `gameModeOverride=120`, `gameDefaultOverride=60`.
The `--fps 120` override works. "Hard-capped at 60" is **not** an absolute statement.

**setprop — confirmed writable:**
```sh
setprop debug.sf.*
setprop debug.hwui.*
setprop debug.renderengine.backend
setprop debug.vulkan.enabled
setprop debug.egl.hw
# debug.adreno.*: some props may read/write, but effect is unverified unless individually tested.
# Do not add undocumented Adreno props to main scripts by default.
setprop debug.input.*
setprop debug.velocitytracker.strategy
setprop persist.sys.perf_turbo_type
# persist.sys.miui_optimization: do not toggle dynamically unless explicitly tested and state-restored.
# Do not treat as a default performance command.
```

**settings binary — confirmed working:**
```sh
settings put/get/delete global/secure/system
```
Note: `cmd settings` via binder returns "Failed transaction" on this build. Use the **binary tool only**.

**AppOps — confirmed working from correct Shizuku/QuickShell context:**
```sh
appops set <package> RUN_IN_BACKGROUND allow
appops set <package> RUN_ANY_IN_BACKGROUND allow
appops set <package> WAKE_LOCK allow
appops get <package> RUN_IN_BACKGROUND
```
Older logs showing "Failed transaction" were context/path-dependent failures, not a universal rule.
Always verify with read-back after setting.

**ActivityManager:**
```sh
am set-standby-bucket com.roblox.client active
am get-standby-bucket com.roblox.client
am compact <PID>              # PID only — not package name
am force-stop <package>
am compat enable OVERRIDE_MIN_ASPECT_RATIO_MEDIUM com.roblox.client
```

**Other confirmed:**
```sh
cmd thermalservice reset          # cleanup only, not spoofing
cmd package compile -m speed-profile -f com.roblox.client
cmd deviceidle whitelist +com.roblox.client
wm size / wm density              # read + write
dumpsys *                         # all readable
```

---

## 6. Confirmed Failed / Rejected

| Command | Reason |
|---|---|
| `am memory-factor-override` | Removed in Android 16 |
| `am send-trim-memory <package>` | IllegalArgumentException on Android 16 |
| `am compact com.roblox.client` | Wrong — must use PID |
| `cmd thermalservice override-status -1` | Invalid range; all values rejected for spoofing |
| `cmd game mode 2 com.roblox.client` | Roblox has no game mode manifest declaration |
| `cmd display density` | Unknown command on this build |
| `device_config put/delete *` | Blocked on this HyperOS build |
| `cmd settings` (binder path) | Failed transaction |
| `cmd activity` (binder path) | Failed transaction |
| `service call SurfaceFlinger 1034 ...` | Executes but does NOT override `game_default_frame_rate_override` |
| `cmd window set-app-smallest-width` | Not a stable shipping command |
| `background_process_limit=2` | Broke ChatGPT and Recents — confirmed harmful |

---

## 7. Current Best Script Design (v7/v8 direction)

State-safe, mode-based structure. No background process limit. No cloned Discord restriction by default.

**Modes:**
```
engage       balanced — downscale 0.35, fps 120
aggressive   competitive — downscale 0.3, fps 120
callmode     leaves Discord user 0 and cloned Discord user 999 unrestricted
stop         restores all state
verify       quick sanity check of key values
verify_full  deep check: renderer, standby bucket, game mode, network
compile_profile  dex2oat speed-profile for Roblox
compile_speed    dex2oat speed for Roblox
```

**Optional A/B only (never default):**
```
display120      optional — `cmd display set-user-preferred-display-mode 1080 2340 120`; applies but throws SecurityException, must NOT be default
displayclear    `cmd display clear-user-preferred-display-mode`
sfplus          optional conservative SF/HWUI A/B test (not phase-offset compression). Candidates (unconfirmed, test individually):
                  setprop debug.sf.predict_hwc_composition_strategy 1
                  setprop debug.sf.enable_adpf_cpu_hint 1
                  setprop debug.sf.frame_rate_multiple_threshold 0
                  optional HWUI ADPF-related props only if readback confirms
driver          ANGLE / native driver toggle — A/B only
```

**Banned from all modes:**
- `background_process_limit=2`
- Cloned Discord restriction
- Thermal spoofing commands

---

## 8. App and Package Notes

| App | Package | Notes |
|---|---|---|
| Roblox | `com.roblox.client` | UID 10490; standby bucket readback may show `5` even after `set active` on this HyperOS build — always compare before/after and verify behavior; do not blindly label numeric `5` as restricted |
| Discord (main) | `com.discord` | user 0 |
| Discord (clone) | `com.discord` | user 999; launch: `com.discord/.main.MainDefault` |
| ChatGPT | `com.openai.chatgpt` | Was broken by background_process_limit=2 |

**Discord clone notes:**
- `callmode` must leave user-999 Discord unrestricted — restricting it drops active calls.
- To target user-999 package: `--user 999` flag in `appops`, `am`, `cmd` where supported.

**Roblox standby:**
```sh
am set-standby-bucket com.roblox.client active
```
Always run before and after launching Roblox. `appops` allow is the most durable suppression — survives force-stop restarts.

---

## 9. Known Problems and Fixes

**`background_process_limit=2` — BANNED:**
- Broke ChatGPT and Recents behavior on this device.
- Fix: `settings put global background_process_limit -1`
- The ChatGPT fix also involved AppOps allow, deviceidle whitelist, and removing the background restriction — but the key final cause was the process limit.

**QuickShell heredoc failures:**
- Large heredocs can fail due to `/data/local` temp permission issues.
- Use `printf` builders or write files to `/storage/emulated/0/Download/` instead.

**`wm density reset` in daemons:**
- Do not use in daemon restore. If daemon exits uncleanly, UI stays broken.
- Use explicit density value restore instead.

**Roblox 360 MB in ZRAM:**
- Confirmed during active session — direct cause of kswapd0 burst-induced frame drops.
- No no-root fix available (ZRAM sysctl requires UID 0).
- Mitigation: keep memory pressure low via standby bucket management and compact on boost entry.

**SchedBoostService + Axeron:**
- Pre-boosts `frb.axeron.manager` to priority -10.
- Close Axeron before gaming to avoid priority pollution.

---

## 10. Diagnostics and Verification

**Roblox gfxinfo baseline (2026-04-16):**

| Test | Pipeline | p50 | p90 | p99 | Legacy janky |
|---|---|---|---|---|---|
| OpenGL baseline | Skia (OpenGL) | 11ms | 36ms | 350ms | 65% |
| Vulkan redirect test | Skia (OpenGL) | 11ms | 32ms | 350ms | 62% |
| ANGLE Vulkan | Skia (Vulkan) | 11ms | 46ms | 350ms | 89% |
| Final boss (optimized) | Skia (Vulkan) | **7ms** | **29ms** | **250ms** | **46%** |

Best result: `Skia (Vulkan)` optimized — p50 7ms, p90 29ms, GPU p99 5ms.
ANGLE path was **not** an improvement over direct Vulkan.

**SF frame duration reference:**
| Hz | Duration (ns) |
|---|---|
| 60 | 16666667 |
| 90 | 11111111 |
| 120 | 8333333 |
| 144 | 6944444 |

Correct value for `late.app.duration` at 120Hz = `11666667`. Using `500000` was confirmed actively harmful.

**Roblox standby check:**
```sh
dumpsys usagestats com.roblox.client | grep "bucket="
```

**Game mode check:**
```sh
dumpsys SurfaceFlinger | grep -A5 "10490"
```

**AppOps read-back:**
```sh
appops get com.roblox.client RUN_IN_BACKGROUND
```

---

## 11. Roblox FFlags — Dead End (No-Root)

- `ClientAppSettings.json` is inside private app data — inaccessible without root.
- Shizuku UID 2000 received `Permission denied` on `/data/user/0/com.roblox.client/...`
- `run-as com.roblox.client` fails — Roblox is not debuggable.
- **Conclusion:** No-root FFlags are a dead end unless an external path is proven.
- FFlag content may exist, but the access path is the blocker.

---

## 12. Driver / ANGLE Status

- `game_driver_opt_in_apps=com.roblox.client` — confirmed found.
- `updatable_driver_production_opt_out_apps=com.roblox.client` — confirmed found (Roblox blacklisted from updatable driver).
- ANGLE forced state confirmed in at least one audit pass.
- **Do not force all-apps driver globally.**
- Driver toggling (ANGLE vs native) must be treated as **A/B test only**, not a default setting.
- Effect on Roblox native renderer requires controlled test to confirm.

---

## 13. Historical / Root-Only / Not Current

The following are **not valid** for current Shizuku-only (UID 2000) scripts.
Do not suggest without explicit root confirmation.

- IRQ pinning to specific cores
- GMU devfreq locking
- KGSL preemption / dispatch priority writes
- CPU uclamp / cgroup edits
- ZRAM lz4 compression switching
- `swapoff` / `swapon` sequences
- MGLRU `min_ttl_ms` writes
- `vm.swappiness` / sysctl tuning
- RPS / RFS / XPS packet steering
- `iptables NOTRACK` for UDP
- Any `/sys/devices/system/cpu/*` write
- Any `/proc/sys/vm/*` write
- Magisk module ZIP structure (`service.sh`, `revert.sh`, `customize.sh`, `module.prop`)
- RedmiBoost v46 three-state daemon (idle/boost/cooldown) with named state functions

These were part of an earlier root-module phase. They are archived here for context only.

---

## 14. Open Tests

- `touch_slop` and `scroll_friction` writability via `settings` — unconfirmed
- Dash button tap responsiveness improvement — input diagnostic pending
- ANGLE vs native driver A/B — pending controlled test
- `service call SurfaceFlinger 1034` actual effect on `gameDefaultOverride` — executes without error, override confirmed NOT working from prior test
- Whether `device_config` becomes writable on future HyperOS builds — monitor

---

## 15. Do Not Forget

- Always verify `setprop` writes with `getprop` read-back.
- Always verify `settings put` with `settings get` read-back. Exit code is not sufficient.
- `cmd settings` binder path fails — use `settings` binary only.
- Roblox standby bucket readback may show `5` even after `set active` on this HyperOS build — always compare before/after; do not blindly label numeric `5` as restricted. Always force active before gaming.
- `am compact` takes PID, never package name.
- `background_process_limit=2` is confirmed harmful on this device — never use.
- Discord user-999 clone must not be restricted during callmode.
- QuickShell heredocs fail on `/data/local` — use `printf` or `/storage/emulated/0/Download/`.
- Close Axeron before gaming (SchedBoostService gives it priority -10).

---

*Sources: getprop_dump, feedback.md, roblox gfxinfo logs (2026-04-16), QuickShell logs, dumpsys_services, userMemories, correction instructions v2.1.*
