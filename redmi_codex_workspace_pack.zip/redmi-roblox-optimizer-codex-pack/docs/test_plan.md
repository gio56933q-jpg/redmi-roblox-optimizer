# v9.2 Test Plan

Use aShell You or AXManager with Roblox active and inside a game where possible.

## Baseline verify

```sh
sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh engage
sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh verify
```

Expected:

```text
Scaling:0.25
Fps:120
{10490, 120 0}
renderRate=120.00 Hz
max_events=9999
debug.tp.grip_enable=90
```

## Gfxinfo check

```sh
dumpsys gfxinfo com.roblox.client | grep -E 'Total frames rendered|Janky frames|90th percentile|95th percentile|99th percentile|Number High input latency|Number Missed Vsync'
```

## A/B test max_events

Only change one variable at a time.

```sh
sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh events9999
# Play 5 minutes, then gfxinfo

sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh events1600
# Play 5 minutes, then gfxinfo

sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh events480
# Play 5 minutes, then gfxinfo
```

Judge by feel, p90/p95, missed vsync, and jank. High input latency alone is not decisive because thermal/ZRAM stalls can inflate it.

## A/B test scale

```sh
sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh scale025
# Play, gfxinfo

sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh scale035
# Play, gfxinfo
```

Reason to test 0.35: visual clarity, Roblox LOD/streaming behavior, and touch-to-visual feedback. Do not claim coordinate scaling CPU overhead unless proven.

## A/B test grip

```sh
sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh grip90
sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh grip120
sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh grip150
```

Current best feel: `grip90`.

## Do not mix tests

Change only one variable per session.
