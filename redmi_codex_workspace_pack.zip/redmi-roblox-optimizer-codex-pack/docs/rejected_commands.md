# Rejected / Banned Commands and Paths

Do not include these in scripts unless the user explicitly requests a dangerous experiment.

## Root-only / blocked

- `/sys` writes
- `/proc` writes
- CPU/GPU governor edits
- IRQ pinning
- ZRAM/sysctl tuning
- cgroup/uclamp edits
- raw `service call`
- `device_config put/delete`
- thermal spoofing like `cmd thermalservice override-status`
- private app data access under `/data/user/0/com.roblox.client`
- `run-as com.roblox.client` because Roblox is not debuggable

## Confirmed harmful or risky

- `settings put global background_process_limit 2` — broke ChatGPT/Recents.
- `am kill-all` — too broad.
- PowerKeeper clear/disable — diagnostic test showed no useful readback change; destructive to settings.
- GMS / Play Store modifications — off limits.
- Discord/cloned Discord restrictions — can break calls.
- Pedometer restriction — user wants pedometer on.

## Dead or useless for this build

- ANGLE keys for Roblox.
- `developer_graphics_driver` / `developer_graphics_driver_packages`.
- `game_driver_*` forcing.
- MiuiForceVkService commands — failed transaction.
- FramerateFineControlService commands — failed transaction.
- TouchFeature HAL commands — service not found.
- fake 144/240 FPS SettingsProvider keys without SurfaceFlinger/GameManager readback.

## Notes

Writable does not mean useful. SettingsProvider can store random keys that no service reads.
