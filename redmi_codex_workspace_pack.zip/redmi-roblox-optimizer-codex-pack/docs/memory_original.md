# Memory File — Giorgi / Redmi HyperOS Optimization Workflow
## Module: RedmiBoost | Target: Roblox competitive gameplay

---

## 1. User Response Preferences

- Direct, critical, practical. No softening of corrections.
- Do not default to agreement. Push back when something is wrong.
- Separate confirmed facts from guesses. Label everything explicitly.
- Avoid hype and fake performance claims.
- Reject root-only, placebo, or unverified tweaks — or label them clearly.
- Prefer exact commands and scripts over conceptual descriptions.
- Praise only when objectively and explicitly justified. If unsure, omit it.
- No theoretical advice, UI navigation, or stability warnings.
- Raw executable `sh` code only. Every command ends with `2>/dev/null || true`.
- Corrections stated as facts, not softened.
- Do not summarize logs — identify the specific bottleneck and write the exact counter-script.

---

## 2. Device / Environment

| Property | Value |
|---|---|
| Device | Redmi 15 4G (codename: creek / missi) |
| Marketname | `ro.product.marketname=Redmi 15` |
| SoC | Qualcomm SM6225 (Snapdragon 685) |
| GPU | Adreno 610 |
| RAM | 8 GB |
| Storage | Internal UFS |
| Android version | **16** (SDK 36) |
| Build ID | BP2A.250605.031.A3 |
| OS | HyperOS OS3.0.10.0.WBOMIXM |
| Kernel | 5.15 |
| Security patch | 2026-02-01 |
| Access level | **No root. Shizuku UID 2000 (shell) via AXManager** |
| Display density | `ro.sf.lcd_density=450` |
| Resolution | 1080×2340 |
| Default idle FPS | 48 Hz |
| Peak FPS | 120 Hz |
| Boot slot | `_b` |
| Bootloader | Locked (`ro.boot.flash.locked=1`) |
| Target app | `com.roblox.client` |
| Roblox UID | **10490** |
| Module installer | AXManager (Magisk-compatible ZIP structure) |
| Script runner | QuickShell / Axeron |

**Core layout (Snapdragon 685):**
- 6-core design, **not** true 8-core big.LITTLE
- "Silver" LITTLE cores: cpu0–cpu5 (A53)
- "Gold" big core pair: cpu6–cpu7 (A73) — internally mapped

**Observed idle frequencies (from QuickShell log 2026-04-16):**
- cpu0 (silver): 1190400 Hz (~1.19 GHz)
- cpu4 (gold): 1766400 Hz (~1.77 GHz) — not at peak, likely thermally limited

---

## 3. Main Goal

Measurably smoother Roblox / The Strongest Battlegrounds gameplay without breaking background apps or system stability. Specific targets:

- Reduced touch-to-action latency
- Higher stable FPS (cap at 120Hz where possible)
- Elimination of kswapd0 burst-induced frame drops
- Lower ping variance / UDP jitter
- No background app kills
- No root required

---

## 4. Hard Constraints — Never Suggest Unless Explicitly Requested

| Constraint | Reason |
|---|---|
| `/sys` writes (CPU governor, GPU freq, IRQ) | Requires UID 0 |
| `/proc/sys/vm/*` sysctl writes | Requires UID 0 |
| IRQ pinning | Requires UID 0 |
| ZRAM/swapoff/swapon via sysfs | Requires UID 0 |
| Thermal spoofing via sysfs | Requires UID 0 |
| All `ro.*` setprops | Tombstoned in HyperOS v16.0 — immutable from UID 2000 |
| `persist.sys.force_sw_gles` | Confirmed `=1` and immutable from UID 2000 |
| `persist.device_config.*` namespace writes | Blocked on this build — "Failed transaction" |
| `device_config put/delete` | Fully blocked. Read (`device_config get`) works |
| `cmd activity` / `cmd settings` via binder | "Failed transaction (2147483646)" on this build |
| Raw `service call` for gameDefaultOverride | `SurfaceFlinger 1034` executes but does NOT override `game_default_frame_rate_override` |
| `am memory-factor-override` | Removed in Android 16 |
| `am send-trim-memory <package>` | Throws IllegalArgumentException on Android 16 |
| `am compact <package_name>` | Invalid syntax — must use PID: `am compact $(pidof pkg)` |
| `cmd game mode 2 com.roblox.client` | Roblox has not declared game mode support in manifest |
| `cmd display density` | Unknown command on this build |
| `pm disable-user` | SecurityException on this build |
| `pm grant/revoke` | SecurityException on this build |
| `wm density reset` in daemons | Unclean exit leaves UI permanently broken |
| `cmd thermalservice override-status -1` | Invalid — valid range is 0–5 only |
| `am kill-all` as a routine call | Too aggressive — breaks background apps |
| `background_process_limit=2` as permanent setting | Kills background apps — never set permanently |
| Touching GMS / Play Store packages | Off limits |
| `com.miui.daemon` treatment as bloat | Do not disable |
| Large heredocs in QuickShell | Crashes parser |
| `adb` commands inside QuickShell | Not available in QuickShell context |
| `appops` / `cmd appops` | Broken on this HyperOS build — "Failed transaction" |

---

## 5. Confirmed Working Commands (UID 2000)

| Command / Vector | Notes |
|---|---|
| `setprop debug.sf.*` | All confirmed writable |
| `setprop debug.hwui.*` | All confirmed writable |
| `setprop debug.renderengine.backend` | Confirmed writable |
| `setprop debug.vulkan.enabled` | Confirmed writable |
| `setprop debug.egl.hw` | Confirmed writable |
| `setprop debug.adreno.*` | Confirmed writable |
| `setprop debug.input.*` | Confirmed writable |
| `setprop debug.velocitytracker.strategy` | Confirmed writable |
| `setprop persist.sys.perf_turbo_type` | Confirmed writable |
| `setprop persist.sys.miui_optimization` | Confirmed writable |
| `settings put/get/delete global/secure/system` | Binary tool — confirmed working. NOT via `cmd settings` binder |
| `am force-stop` | Working |
| `am set-standby-bucket` | Working |
| `am get-standby-bucket` | Working |
| `am compact <PID>` | Working — **PID only**, not package name |
| `appops set/get` (binary tool) | Working for: `RUN_IN_BACKGROUND`, `RUN_ANY_IN_BACKGROUND`, `WAKE_LOCK` |
| `cmd thermalservice override-status 0` | Working (0 = NONE) |
| `cmd power set-adaptive-power-saver-enabled` | Working |
| `cmd package compile` | Working |
| `cmd deviceidle whitelist +/-` | Working |
| `cmd game set --downscale / --fps` | Confirmed working at UID 2000 |
| `service call SurfaceFlinger 1013/1014` | Working |
| `wm size` / `wm density` (read + write) | Working |
| `dumpsys *` | All readable |
| `logcat` | Working |
| `device_config get` | Read works; write does not |
| `am compat enable OVERRIDE_MIN_ASPECT_RATIO_MEDIUM` | Works — achieves ~3:2, not true 4:3 |

**Note on `settings` vs `cmd settings`:**
The `settings` binary tool works. The `cmd settings` binder path returns "Failed transaction (2147483646)". Always use the binary, never the binder path.

---

## 6. Confirmed Dead / Broken Commands — Never Use Again

| Command | Reason |
|---|---|
| `cmd thermalservice override-status -1` | Invalid value. Valid range 0–5 |
| `am memory-factor-override` | Removed in Android 16 |
| `am send-trim-memory <package>` | IllegalArgumentException on Android 16 |
| `am compact com.roblox.client` | Wrong syntax. Use PID |
| `device_config put *` | Bad arguments — all namespaces blocked on this build |
| `device_config delete *` | Same — fully blocked |
| `cmd game mode 2 com.roblox.client` | Roblox has no game mode manifest declaration |
| `cmd display density` | Unknown command on this build |
| `pm disable-user` | SecurityException |
| `pm grant/revoke` | SecurityException |
| `wm density reset` | Avoid in daemons — causes permanent broken UI on unclean exit |
| All `ro.*` setprops | Immutable under any circumstance from UID 2000 |
| `persist.device_config.*` namespace writes | Blocked — Failed transaction |
| `cmd settings` (binder path) | Failed transaction on this build |
| `cmd activity` (binder path) | Failed transaction on this build |
| `service call SurfaceFlinger 1034 i32 <uid> f 0.0 f 0.0` | Executes without error but does NOT override `game_default_frame_rate_override` |
| `cmd window set-app-smallest-width` | Not a stable shipping command — avoid |
| `persist.device_config.runtime.*` write | Not writable from UID 2000 — ART JIT expansion removed |

---

## 7. Hard Ceilings — Cannot Fix Without Root

| Issue | Root Cause |
|---|---|
| Roblox hard-capped at 60fps | `ro.surface_flinger.game_default_frame_rate_override=60` — immutable. `service call SurfaceFlinger 1034` does not override it |
| Software GLES forced | `persist.sys.force_sw_gles=1` — confirmed in getprop, immutable from UID 2000 |
| CPU governor / frequency scaling | `/sys/devices/system/cpu/*` write requires UID 0 |
| ZRAM / sysctl tuning | `/proc/sys/vm/*` requires UID 0 |
| `ro.surface_flinger.enable_frame_rate_override=false` | Immutable |

---

## 8. Key Device State (from getprop dump, confirmed)

```
persist.sys.force_sw_gles=1                     ← HARD BLOCKER (immutable)
ro.surface_flinger.game_default_frame_rate_override=60   ← HARD BLOCKER (immutable)
ro.surface_flinger.enable_frame_rate_override=false      ← confirmed
debug.hwui.renderer=skiavkthreaded              ← Vulkan active for HWUI
debug.hwui.render_backend=skiavk
debug.renderengine.backend=skiavkthreaded
debug.vulkan.enabled=1
debug.sf.auto_latch_unsignaled=1
debug.sf.latch_unsignaled=1
debug.sf.disable_backpressure=1
debug.sf.ignore_present_fences=1
debug.sf.compbypass.enable=1
debug.input.resampling=true                     ← currently ON (our module disables it)
debug.input.filter=0
debug.velocitytracker.strategy=lsq2             ← baseline; module sets to impulse during gaming
persist.vendor.dfps.level=120
ro.vendor.display.default_fps=48
ro.vendor.display.idle_default_fps=48
persist.sys.perf_turbo_type=19
persist.sys.turbosched.enable=true
persist.sys.miui_optimizer=true
persist.device_config.aconfig_flags.core_graphics...vulkan_renderengine=true
persist.device_config.aconfig_flags.activity_manager_native_boot.use_freezer=true
persist.sys.mem_cgated=1
persist.sys.mem_fgated=1
```

**Roblox-specific state confirmed:**
- Roblox standby bucket: **5 (RESTRICTED)** — must always force to ACTIVE before/during gaming
- Roblox had 360 MB paged into ZRAM during active session — direct cause of kswapd0 frame bursts
- Roblox was blacklisted in `updatable_driver_production_opt_out_apps` despite `game_driver_all_apps=1` — addressed in module
- Battery saver was confirmed pinned ON at system level via HyperOS — addressed in module

---

## 9. Roblox Graphics Performance Baseline Data

All data from `dumpsys gfxinfo com.roblox.client`. Captured 2026-04-16.

### roblox_gfx.txt — OpenGL baseline (pid 26083)
```
Pipeline:       Skia (OpenGL)
Frames:         1437
Janky:          3.55% (modern) / 65.07% (legacy)
p50:            11ms  |  p90: 36ms  |  p95: 101ms  |  p99: 350ms
GPU p50: 2ms  |  GPU p90: 3ms  |  GPU p99: 8ms
High input latency events: 2542
```

### roblox_vk_test.txt — Vulkan redirect test, still showing OpenGL (pid 26083, same session)
```
Pipeline:       Skia (OpenGL)  ← persist.sys.force_sw_gles=1 prevented Vulkan takeover
Frames:         1952
Janky:          3.28% / 62.30% (legacy)
p50:            11ms  |  p90: 32ms  |  p99: 350ms
Note: GPU cache collapsed to 48KB vs 2MB in OpenGL run — probable renderer restart artifact
```

### roblox_angle.txt — ANGLE/Vulkan attempt (pid 24761, new session)
```
Pipeline:       Skia (Vulkan)  ← Vulkan achieved
Frames:         392
Janky:          4.08% / 88.78% (legacy)  ← WORSE legacy metric
p50:            11ms  |  p90: 46ms  |  p99: 350ms
GPU p99: 15ms  ← worse GPU tail
```

### roblox_final_boss.txt — Best result achieved (pid 11177, optimized session)
```
Pipeline:       Skia (Vulkan)  ← Vulkan active
Frames:         442
Janky:          3.17% / 45.70% (legacy)  ← BEST legacy metric
p50:            7ms   |  p90: 29ms  |  p95: 85ms  |  p99: 250ms  ← BEST
GPU p50: 1ms  |  GPU p90: 1ms  |  GPU p95: 2ms  |  GPU p99: 5ms  ← BEST
High input latency events: 767 (lowest of all sessions)
```

**Conclusion from data:**
- Best pipeline confirmed: `Skia (Vulkan)`
- Best result: `roblox_final_boss` — p50 7ms, p90 29ms, GPU p99 5ms
- ANGLE path did NOT improve performance vs direct Vulkan
- `persist.sys.force_sw_gles=1` is the root blocker — Vulkan in HWUI (`skiavkthreaded`) does not override Roblox's native renderer
- High input latency counter (767–3515) is persistent across all sessions — dominated by systemic input pipeline issue, not renderer

---

## 10. Module Architecture — RedmiBoost (current: v46)

### Structure
Standard Magisk ZIP layout:
- `service.sh` — main daemon + boost/idle state machine
- `revert.sh` — full restore to pre-module state
- `customize.sh` — install-time setup
- `module.prop` — version metadata

### State Machine
Three-state daemon: `idle → boost → cooldown`

Named transition functions:
- `apply_boost_state()` — fires when Roblox foreground detected
- `restore_idle_state()` — fires when Roblox exits foreground
- `thermal_tick()` — thermal watchdog inside boost loop

Daemon is pinned to LITTLE core. Confirmed clean — no memory leak risk over extended sessions.

### Subsystems Active in v46

**Touch input pipeline:**
- IRQ pinning to cores 6–7
- InputReader resampling disable
- PalmRejector bypass
- Xiaomi TouchFeature HAL sysfs game mode nodes
- Touch filter coefficient zeroing

**GPU:**
- GMU devfreq locking
- KGSL preemption and dispatch priority
- Vulkan renderer redirect (`debug.hwui.renderer vulkan`) as primary non-root workaround

**CPU/Scheduler:**
- uclamp floors/ceilings across top-app and background cgroups
- Dynamic `FAST_MASK` detection via `detect_fast_core()`
- Thread sniper (`snipe_threads()`) with `LAST_SNIPE_PID` guard

**Memory:**
- ZRAM lz4 compression switch with free RAM guard
- Safe swapoff/reset/swapon sequence
- MGLRU `min_ttl_ms`, swappiness tuning
- Background app preservation enforced

**Network:**
- RPS/RFS/XPS packet steering to cores 6–7
- UDP busy-poll
- `udp_rmem_min` tuning
- iptables NOTRACK for UDP (silent-fail expected in non-root via `try` wrapper)

**SurfaceFlinger/display:**
- `debug.sf.latch_unsignaled=0` with `auto_latch_unsignaled=1`
- FPS overrides corrected to 144 (was incorrectly 90 in three locations)
- Game overlay downscale factor applied

**Game Manager API:**
- `cmd game mode performance`
- `cmd game set --downscale`
- `cmd game set --fps`
- All confirmed working at UID 2000

**ActivityManager:**
- `compact --full` targeting live Roblox PID inside `apply_boost_state()`
- Explicitly excludes `--memory-factor --set CRITICAL` to preserve background apps

**Battery saver:**
- OFF during gameplay, ON after game closes
- HyperOS was confirmed pinning battery saver ON — addressed

---

## 11. Known Architecture Bugs / Past Mistakes — Must Not Repeat

1. **SF duration 500000ns** — sent for `late.app.duration`. Correct for 120Hz is `11666667ns`. 500000ns was actively harmful.
2. **`am compact com.roblox.client`** — invalid. Must use PID.
3. **`cmd game`, `cmd thermalservice`, `cmd display`** — assumed working before capability audit. All were silently dead.
4. **`debug.adreno.vulkan_pipeline_cache_size`** — not documented. Effect unverified.
5. **`pm disable-user` in daemon** — throws SecurityException.
6. **`wm density reset` in daemon restore** — daemon died uncleanly, device UI stayed broken permanently.
7. **`cmd thermalservice override-status -1`** — invalid value on this build.
8. **Settings false positive in capability test** — always verify with read-back, not exit code.
9. **Section ordering conflict** — Section 24 overwrote Section 10's scheduler baseline. Audit for duplicate writes when adding new sections.
10. **Duplicate sysctl writes with inconsistent values** — confirmed bug: `netdev_budget` written three times with different values.
11. **Missing `device_config delete` in restore** — confirmed past bug. Every boost write needs a symmetric restore.
12. **`wm` commands race with NDK init** — ineffective for aspect ratio spoofing.

---

## 12. Scripting Standards and Patterns

### Required patterns in all scripts

```sh
# Absolute path variables — mandatory for Shizuku stripped PATH
WM=/system/bin/wm
SETTINGS=/system/bin/settings
SYSCTL=/system/bin/sysctl
SETPROP=/system/bin/setprop
CMD=/system/bin/cmd
PM=/system/bin/pm
DUMPSYS=/system/bin/dumpsys

# try wrapper — graceful silent failure
try() { "$@" 2>/dev/null || true; }

# write_if_writable helper — use before every sysfs write
write_if_writable() {
  [ -w "$1" ] && echo "$2" > "$1" 2>/dev/null || true
}

# Every daemon must have:
trap 'restore_idle_state; exit 0' TERM INT HUP
```

### Boost/restore symmetry rule
Every sysfs write in `apply_boost_state()` must have a corresponding restore in both `restore_idle_state()` and `revert.sh`. No exceptions.

### Section ordering rule
Sections injected later can silently overwrite earlier ones. Always grep for duplicate sysfs node targets when adding a new section.

### Verification rule
Every `setprop` write must be verified with `getprop` read-back. Every `settings put` write must be verified with `settings get` read-back. Exit code alone is not sufficient.

### Shizuku boot timing rule
Shizuku must be running at boot before `service.sh` fires. If `appops` lines fire before Shizuku is ready, they silently no-op.

---

## 13. Thermal Watchdog Standard

Thermal failsafe must use:
- **Derivative check** (rate of change AND absolute threshold) — not a simple ceiling
- **Hysteresis on recovery** — do not flip back to boost immediately after cooldown
- No Joyose or thermal variables — explicitly out of scope

---

## 14. Active Services of Interest (from dumpsys)

Services confirmed present and running on this device:
```
SchedBoostService          ← pre-boosts frb.axeron.manager to priority -10
MiuiForceVkService         ← Xiaomi Vulkan force service
FramerateFineControlService
MiuiInputManager
HyperOSCustFeatureResolve
miui.downscale             ← confirmed present
miui.fbo.service
SchedBoostService          ← close Axeron before gaming (it gets priority -10 boost)
turbosched                 ← confirmed active
vendor.perfservice
game                       ← Game Manager confirmed available
```

**SchedBoostService note:** Pre-boosts `frb.axeron.manager` to priority -10. Close Axeron before gaming to avoid priority pollution.

---

## 15. Roblox App Standby State

From QuickShell log 2026-04-16:
```
package=com.roblox.client u=0 bucket=5 reason=d
```
- Bucket 5 = **RESTRICTED**
- Must always run `am set-standby-bucket com.roblox.client active` before and after launching Roblox
- `appops` set for `RUN_IN_BACKGROUND` and `RUN_ANY_IN_BACKGROUND` is the most durable suppression method — survives force-stop restarts

---

## 16. Input Preferences

| Setting | Value | Status |
|---|---|---|
| Velocity tracker strategy (gaming) | `impulse` | Confirmed preferred |
| Velocity tracker strategy (baseline) | `lsq2` | Device default |
| User pointer_speed baseline | `1` | Confirmed |
| `touch_slop` writability | Unknown | Unconfirmed — pending input diagnostic |
| `scroll_friction` writability | Unknown | Unconfirmed — pending input diagnostic |
| Dash button tap responsiveness | Open issue | Input diagnostic pending |

---

## 17. Open Issues / On the Horizon

- `touch_slop` and `scroll_friction` writability: unconfirmed, pending input diagnostic
- Dash button tap responsiveness: open issue, input diagnostic pending
- `service call SurfaceFlinger 1034` effect on `gameDefaultOverride`: executes without error, actual override effect **unconfirmed**
- Whether `device_config` or `appops` become accessible on future HyperOS builds: monitor
- Continued iteration as HyperOS behavior is observed in practice

---

## 18. Reference Data

**SF frame durations at common refresh rates:**
| Hz | Frame duration (ns) |
|---|---|
| 60 | 16666667 |
| 90 | 11111111 |
| 120 | 8333333 |
| 144 | 6944444 |

**Correct value for late.app.duration at 120Hz:** `11666667` (not 500000 — that was a confirmed harmful bug)

**Roblox UID:** 10490  
**Roblox package:** `com.roblox.client`  
**Roblox last known PID pattern:** dynamic — always retrieve via `pidof com.roblox.client`

---

*Last updated from: getprop_dump, feedback.md, roblox_gfx/vk_test/angle/final_boss gfxinfo logs, QuickShell logs 2026-04-16, dumpsys_services, userMemories (RedmiBoost v46 session history)*
