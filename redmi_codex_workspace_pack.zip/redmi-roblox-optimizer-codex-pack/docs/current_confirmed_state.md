# Current Confirmed State

## Best profile currently confirmed

- Downscale: `0.25`
- FPS override: `120`
- SurfaceFlinger override: `{10490, 120 0}`
- Display active mode: `120 Hz`
- Input dispatcher max events: `9999`
- Input resampling: `false`
- Touch prediction: `false`
- Velocity tracker: `impulse`
- Grip prop: `debug.tp.grip_enable=90`
- `sys.tp.grip_enable` may stay `0` or fail to set; do not depend on it.
- Roblox in DeviceIdle whitelist.
- Roblox AppOps explicit allow for `RUN_IN_BACKGROUND`, `RUN_ANY_IN_BACKGROUND`, and `WAKE_LOCK`.

## Latest aShell You readback

The latest readback confirmed:

```text
GameManager: Scaling:0.25, Fps:120, Use Angle:false
SurfaceFlinger: {10490, 120 0}
renderRate=120.00 Hz
activeMode=120.00 Hz
max_events=9999
grip_debug=90
grip_sys=0
bucket=5
RUN_IN_BACKGROUND: allow
RUN_ANY_IN_BACKGROUND: allow
WAKE_LOCK: allow
```

`bucket=5` is a known HyperOS drift issue. Reapply standby active periodically, but do not assume readback will permanently stay active.

## Best recent gfxinfo with this profile

One run showed:

```text
Total frames rendered: 434
Janky frames: 7 (1.61%)
90th percentile: 17ms
95th percentile: 26ms
99th percentile: 250ms
Number Missed Vsync: 4
Number High input latency: 848
```

Interpretation: mostly stable, but rare large stalls remain. Remaining stutters are likely thermal/ZRAM/Roblox loading rather than missing driver magic.
