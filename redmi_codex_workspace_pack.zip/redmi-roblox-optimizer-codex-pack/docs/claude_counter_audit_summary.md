# Claude Counter-Audit Summary

Claude corrected several earlier overclaims after GPT-5.5 Thinking counter-analysis.

## Corrections accepted

- ANGLE being installed was overclaimed. `angleLoadingCount` is an anomaly; do not assert usable ANGLE runtime without direct path/package/APEX proof. The practical conclusion is that ANGLE injection for Roblox is closed.
- `max_events_per_sec=9999` is not confirmed harmful. It produced one of the best real test results and should be A/B tested against 1600 and 480.
- 0.25 downscale coordinate-transform CPU overhead was overstated. Test 0.35 for visual clarity, Roblox behavior, and touch-to-visual feedback, not because matrix scaling is assumed expensive.
- MiuiForceVkService and FramerateFineControlService are no longer unexplored; full diagnostic showed failed transaction from UID 2000.

## Claims that still stand

- Thermal status and ZRAM/page faults are the main remaining causes of tail-frame spikes.
- Roblox uses real Adreno GPU resources, so pure software rendering theory is dead.
- `{10490, 120 0}` is a strong positive SurfaceFlinger state.
- Explicit Roblox AppOps, DeviceIdle whitelist, standby active reapply, and `am compact <PID>` are appropriate no-root mitigations.
