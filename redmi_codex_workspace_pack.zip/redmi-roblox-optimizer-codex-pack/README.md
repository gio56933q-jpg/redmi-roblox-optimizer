# Redmi Roblox Optimizer — Codex Workspace Pack

This repo is for maintaining a no-root Roblox optimization shell script for:

- Device: Redmi 15 4G
- OS: HyperOS 3 / Android 16
- SoC/GPU: Snapdragon 685 / Adreno 610
- RAM: 6 GB
- Access: Shizuku / ADB shell only, `uid=2000(shell)`, SELinux enforcing
- Target app: `com.roblox.client`

Codex should use this repo for **safe script maintenance**, not for inventing random Android tweaks.

## Current confirmed best manual profile

```sh
settings put global low_power 0
settings put global low_power_sticky 0
settings put system min_refresh_rate 120.0
settings put system peak_refresh_rate 120.0
settings put system user_refresh_rate 120.0
settings put system miui_refresh_rate 120

cmd game set --downscale 0.25 --fps 120 com.roblox.client
cmd game mode custom com.roblox.client

setprop debug.inputdispatcher.max_events_per_sec 9999
setprop debug.input.resampling false
setprop debug.input.touch_prediction false
setprop debug.velocitytracker.strategy impulse
setprop debug.tp.grip_enable 90
setprop sys.tp.grip_enable 90 2>/dev/null

cmd deviceidle whitelist +com.roblox.client
am set-inactive com.roblox.client false
am set-standby-bucket com.roblox.client active

appops set com.roblox.client RUN_IN_BACKGROUND allow
appops set com.roblox.client RUN_ANY_IN_BACKGROUND allow
appops set com.roblox.client WAKE_LOCK allow
```

## Current proof points

Latest aShell You readback confirmed:

- Shell context: `uid=2000(shell)`, `u:r:shell:s0`, SELinux enforcing
- GameManager: `Scaling:0.25`, `Fps:120`, `Use Angle:false`
- SurfaceFlinger: `{10490, 120 0}`
- Active display: `renderRate=120.00 Hz`, `activeMode=120.00 Hz`
- Input props: `max_events=9999`, `resampling=false`, `touch_prediction=false`, `velocitytracker=impulse`, `debug.tp.grip_enable=90`
- Roblox AppOps: explicit `RUN_IN_BACKGROUND`, `RUN_ANY_IN_BACKGROUND`, and `WAKE_LOCK` allow
- DeviceIdle whitelist: `com.roblox.client` added

Known caveat: `am get-standby-bucket com.roblox.client` may still read `5` because HyperOS dynamically drags the app back. Scripts should reapply active bucket periodically, but not rely on it as a perfect readback.

## How to use on phone

Copy script to:

```text
/storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh
```

Run with aShell You or AXManager:

```sh
chmod +x /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh
sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh engage
sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh verify
```

Stop/restore:

```sh
sh /storage/emulated/0/Download/redmi_roblox_v9_2_adaptive.sh stop
```

## Codex role

Codex should:

- Maintain script correctness.
- Preserve restore logic.
- Add clean A/B modes.
- Avoid dangerous broad `pkill` patterns.
- Avoid root-only or fake commands.
- Use the uploaded logs as source of truth.

Codex should **not** invent new tweak lists.
